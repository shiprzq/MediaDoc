import { useEffect, useState } from 'react'
import { fmtBytes } from '../lib/format'
import type { ScanSegment } from '../lib/types'
import CoverageStrip from './CoverageStrip'

export default function AnalyzingView({
  fileName, fileSize, scanned, total, segments, startedAt, queueLabel,
}: {
  fileName: string
  fileSize: number
  scanned: number
  total: number
  segments: ScanSegment[]
  startedAt: number
  queueLabel?: string
}) {
  const [ms, setMs] = useState(0)

  useEffect(() => {
    setMs(0)
    const t = window.setInterval(() => setMs(Math.max(1, Math.round(performance.now() - startedAt))), 97)
    return () => window.clearInterval(t)
  }, [startedAt])

  return (
    <section className="mx-auto max-w-3xl px-4 pb-16 sm:px-6">
      <div className="panel">
        <div className="flex items-center justify-between border-b border-line px-5 py-3">
          <p className="font-mono text-[11px] font-semibold uppercase tracking-[0.2em] text-mute">
            Reading file{queueLabel ? `; ${queueLabel}` : ''}
          </p>
          <p className="font-mono text-[11px] tabular-nums text-mute">{ms} ms</p>
        </div>
        <div className="space-y-4 px-5 py-6">
          <p className="truncate font-mono text-sm font-medium text-ink" title={fileName}>
            {fileName} <span className="text-mute">({fmtBytes(fileSize)})</span>
          </p>
          <CoverageStrip segments={segments} total={total} />
          <div className="flex flex-wrap items-baseline justify-between gap-2 font-mono text-[11px] text-mute">
            <span>
              bytes read: {fmtBytes(scanned)} of {fmtBytes(total)}
            </span>
            <span>
              {segments.length} segment{segments.length === 1 ? '' : 's'} requested by MediaInfo
            </span>
          </div>
          <p className="text-xs leading-relaxed text-mute">
            MediaInfo seeks to the byte ranges it needs (headers, index, trailing metadata). The bar above shows
            the actual ranges read from your file, live.
          </p>
        </div>
      </div>
    </section>
  )
}
