export default function Navbar() {
  return (
    <header className="sticky top-0 z-40 border-b border-ink bg-surface">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6">
        <a href="#top" className="flex items-center gap-2.5">
          <span className="flex h-7 w-7 items-center justify-center bg-ink font-mono text-base font-semibold leading-none text-brand">
            +
          </span>
          <span className="text-lg font-bold tracking-tight text-ink">MediaDoc</span>
          <span className="hidden font-mono text-[11px] uppercase tracking-[0.18em] text-mute sm:inline-block">
            media compatibility doctor
          </span>
        </a>
        <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-mute">
          Local analysis <span className="text-ink">/</span> no uploads
        </p>
      </div>
    </header>
  )
}
