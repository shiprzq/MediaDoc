import { useState } from 'react'

const FAQS: { q: string; a: string }[] = [
  {
    q: 'Why does my file play in VLC but not in the browser?',
    a: 'VLC ships its own decoders for almost everything ever made: MKV containers, DTS sound, HEVC, 10-bit H.264 and more. Browsers only bundle a small set of royalty-cleared codecs, typically H.264, VP9 and AV1 for video and AAC, MP3 and Opus for audio, inside MP4 or WebM containers. Anything outside that list needs conversion.',
  },
  {
    q: 'The video plays but there is no sound. What is going on?',
    a: 'Almost always the soundtrack is DTS, Dolby TrueHD, or AC-3 on a device that cannot decode it (Chrome, Firefox, and many newer Samsung/LG TVs dropped DTS). The fix is cheap: copy the video stream untouched and convert only the audio to AAC for browsers, or AC-3 for TVs. It takes seconds because the video is not re-encoded.',
  },
  {
    q: 'What is Hi10P and why will my anime not play on the TV?',
    a: 'Hi10P is 10-bit H.264, popular in anime releases because it compresses well and avoids banding. The catch: no hardware decoder supports 10-bit H.264 (hardware jumped straight to 10-bit HEVC). Only software players like VLC and mpv decode it. For TVs, phones and browsers, re-encode to standard 8-bit H.264.',
  },
  {
    q: 'Why does HEVC work on my phone but not in Firefox?',
    a: 'HEVC is patent-encumbered, so browsers do not bundle a decoder; they borrow one from the operating system or GPU. Apple ships HEVC everywhere, Windows offers it as an add-on, Chrome uses it when your GPU has one (Chrome 107+), and Firefox only recently added it on some platforms. H.264 has no such drama, which is why it remains the safe choice.',
  },
  {
    q: 'What is the safest format for sharing a video?',
    a: 'MP4 containing H.264 video (High profile, level 4.1, 8-bit 4:2:0) and AAC-LC stereo audio at 128 to 192 kb/s. That exact combination plays on essentially everything made since about 2010: every browser, phone, TV, console and projector. Add -movflags +faststart if you host it on the web so playback starts quickly.',
  },
  {
    q: 'Do I need to re-encode, or just remux?',
    a: 'If only the container is wrong (say, H.264 + AAC sitting in an MKV), a remux copies the streams into an MP4 without touching the quality, and it finishes in seconds. You only need a full re-encode when a codec itself is unsupported, which takes longer and costs a little quality (CRF 18 to 22 keeps it visually lossless). MediaDoc tells you which situation you are in.',
  },
]

export default function FaqSection() {
  const [open, setOpen] = useState<number | null>(0)
  return (
    <div className="border-t border-line">
      {FAQS.map((item, i) => {
        const isOpen = open === i
        return (
          <div key={i} className="border-b border-line">
            <button
              onClick={() => setOpen(isOpen ? null : i)}
              className="flex w-full items-center justify-between gap-4 py-4 text-left"
              aria-expanded={isOpen}
            >
              <span className={`text-sm font-semibold sm:text-base ${isOpen ? 'text-ink' : 'text-ink/80'}`}>
                {item.q}
              </span>
              <span className="shrink-0 font-mono text-sm text-mute">{isOpen ? '[ - ]' : '[ + ]'}</span>
            </button>
            {isOpen && <p className="max-w-3xl pb-5 text-sm leading-relaxed text-mute">{item.a}</p>}
          </div>
        )
      })}
    </div>
  )
}
