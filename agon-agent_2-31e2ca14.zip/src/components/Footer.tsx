export default function Footer() {
  return (
    <footer className="border-t-2 border-ink">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:grid-cols-3 sm:px-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex h-6 w-6 items-center justify-center bg-ink font-mono text-sm font-semibold leading-none text-brand">+</span>
            <span className="text-sm font-bold text-ink">MediaDoc</span>
          </div>
          <p className="mt-3 max-w-xs text-xs leading-relaxed text-mute">
            A media compatibility checker. It reads a file's container, codecs, tracks and subtitles, estimates
            where the file plays, measures this device with a real playback test, and writes the conversion
            command when something fails.
          </p>
        </div>
        <div>
          <p className="font-mono text-[11px] font-semibold uppercase tracking-[0.18em] text-ink">Privacy</p>
          <p className="mt-3 max-w-xs text-xs leading-relaxed text-mute">
            Parsing runs in your browser via MediaInfo compiled to WebAssembly. Files are never uploaded, stored
            or logged. Disconnect from the internet after load and every feature still works.
          </p>
        </div>
        <div>
          <p className="font-mono text-[11px] font-semibold uppercase tracking-[0.18em] text-ink">Method and limits</p>
          <p className="mt-3 max-w-xs text-xs leading-relaxed text-mute">
            Estimates come from published codec and container support of current stable platforms; hardware, OS
            versions and codec packs vary. The live test measures your actual browser, and the raw MediaInfo data
            is shown unedited. When it matters, test on the real device.
          </p>
        </div>
      </div>
    </footer>
  )
}
