import type { ScanSegment } from '../lib/types'

/** Draws which byte ranges of the file were actually read. */
export default function CoverageStrip({ segments, total }: { segments: ScanSegment[]; total: number }) {
  if (total <= 0) return null
  return (
    <div
      className="relative h-4 w-full border border-ink/25 bg-surface"
      title="Byte ranges of the file that MediaInfo actually read"
    >
      {segments.map((s, i) => {
        const left = (s.offset / total) * 100
        const width = Math.max((s.length / total) * 100, 0.4)
        return (
          <span
            key={i}
            className="absolute top-0 h-full bg-ink"
            style={{ left: `${left}%`, width: `${Math.min(width, 100 - left)}%` }}
          />
        )
      })}
    </div>
  )
}
