import type { DiagnosisItem } from '../lib/types'
import { SEV } from '../lib/status'

export default function DiagnosisPanel({ items }: { items: DiagnosisItem[] }) {
  if (items.length === 0) {
    return (
      <div className="panel border-l-4 border-l-ok px-5 py-5">
        <p className="text-base font-semibold text-ink">No problems found</p>
        <p className="mt-1 text-sm text-mute">
          Every tested target can play this file according to the support tables. The live test above confirms
          what this device does.
        </p>
      </div>
    )
  }

  return (
    <div className="panel divide-y divide-line">
      {items.map((item, i) => {
        const sev = SEV[item.severity]
        const shown = item.affects.slice(0, 6)
        const more = item.affects.length - shown.length
        return (
          <div key={`${item.component}-${i}`} className="border-l-4 px-5 py-4" style={{ borderLeftColor: sev.hex }}>
            <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <span className={`font-mono text-[10px] font-bold uppercase tracking-[0.18em] ${sev.text}`}>
                {sev.label}
              </span>
              <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-mute">{item.component}</span>
            </div>
            <p className="mt-1.5 text-sm font-medium leading-relaxed text-ink">{item.title}</p>
            {item.detail && <p className="mt-1 text-xs leading-relaxed text-mute">{item.detail}</p>}
            {item.fix && (
              <p className="mt-1.5 text-xs leading-relaxed text-ink">
                <span className="font-semibold">Fix: </span>{item.fix}
              </p>
            )}
            <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
              <span className="font-mono text-[10px] uppercase tracking-wider text-mute">affects:</span>
              {shown.map((name) => (
                <span key={name} className="border border-line bg-paper px-1.5 py-0.5 font-mono text-[10px] text-mute">
                  {name}
                </span>
              ))}
              {more > 0 && <span className="font-mono text-[10px] text-mute">+{more} more</span>}
            </div>
          </div>
        )
      })}
    </div>
  )
}
