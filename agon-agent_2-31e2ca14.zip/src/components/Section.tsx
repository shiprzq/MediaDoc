import type { ReactNode } from 'react'

export function SectionHeading({
  eyebrow, title, sub,
}: {
  eyebrow: string
  title: ReactNode
  sub?: string
}) {
  return (
    <div className="mb-8 border-t-2 border-ink pt-4">
      <p className="font-mono text-[11px] font-semibold uppercase tracking-[0.2em] text-mute">{eyebrow}</p>
      <h2 className="mt-2 text-2xl font-bold tracking-tight text-ink sm:text-3xl">{title}</h2>
      {sub && <p className="mt-2 max-w-2xl text-sm leading-relaxed text-mute">{sub}</p>}
    </div>
  )
}
