import { useState } from 'react'
import type { Prescription } from '../lib/types'

function CommandBlock({ command }: { command: string }) {
  const [copied, setCopied] = useState(false)
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(command)
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1600)
    } catch {
      /* clipboard unavailable */
    }
  }
  return (
    <div className="mt-4 border border-ink/60 bg-[#141413]">
      <div className="flex items-center justify-between border-b border-white/15 px-4 py-2">
        <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-white/50">ffmpeg command</span>
        <button
          onClick={copy}
          className="border border-white/25 px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-white/70 hover:bg-surface hover:text-ink"
          aria-label="Copy command"
        >
          {copied ? 'copied' : 'copy'}
        </button>
      </div>
      <pre className="code-scroll overflow-x-auto px-4 py-3.5 font-mono text-xs leading-relaxed text-[#e8e8e2]">
        <span className="select-none text-white/40">$ </span>
        {command}
      </pre>
    </div>
  )
}

export default function PrescriptionPanel({ prescriptions }: { prescriptions: Prescription[] }) {
  return (
    <div className="space-y-4">
      {prescriptions.map((p) => (
        <div key={p.id} className={`panel px-5 py-5 sm:px-6 ${p.recommended ? 'border-l-4 border-l-ink' : ''}`}>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
            <h4 className="text-base font-semibold text-ink">{p.title}</h4>
            {p.recommended && (
              <span className="bg-ink px-2 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-surface">
                recommended
              </span>
            )}
          </div>
          <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-mute">{p.subtitle}</p>

          {p.command && <CommandBlock command={p.command} />}

          {p.notes.length > 0 && (
            <ul className="mt-4 grid gap-x-8 gap-y-1.5 sm:grid-cols-2">
              {p.notes.map((note, j) => (
                <li key={j} className="flex items-start gap-2 text-xs leading-relaxed text-mute">
                  <span className="mt-1.5 h-1 w-1 shrink-0 bg-ink" />
                  {note}
                </li>
              ))}
            </ul>
          )}
        </div>
      ))}

      <p className="text-xs leading-relaxed text-mute">
        Prefer a graphical tool? Open the file in HandBrake, choose the preset "Fast 1080p30" and set the format
        to MP4; that applies the same H.264 + AAC recipe. The commands above need{' '}
        <a href="https://ffmpeg.org/download.html" target="_blank" rel="noreferrer" className="text-ink underline underline-offset-2 hover:text-brand">
          ffmpeg
        </a>{' '}
        installed.
      </p>
    </div>
  )
}
