import { fmtDuration, fmtRes } from '../lib/format'
import type { ProbeResult, ProbeStatus } from '../lib/probe'
import type { AnalysisReport } from '../lib/types'
import { STATUS } from '../lib/status'

const STATUS_TEXT: Record<ProbeStatus, { word: string; cls: string }> = {
  plays: { word: 'PLAYS', cls: 'text-ok' },
  partial: { word: 'PARTIAL', cls: 'text-warn' },
  fails: { word: 'FAILS', cls: 'text-bad' },
  unknown: { word: 'UNKNOWN', cls: 'text-mute' },
}

function Row({ label, value }: { label: string; value?: string }) {
  if (!value) return null
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-line py-2 last:border-b-0">
      <dt className="font-mono text-[11px] uppercase tracking-[0.14em] text-mute">{label}</dt>
      <dd className="text-right font-mono text-xs text-ink">{value}</dd>
    </div>
  )
}

export default function ProbePanel({
  probe, probing, report, onRerun,
}: {
  probe: ProbeResult | null
  probing: boolean
  report: AnalysisReport
  onRerun: () => void
}) {
  const predicted = probe?.targetId
    ? report.verdicts.find((v) => v.target.id === probe.targetId)
    : undefined
  const measuredLevel =
    probe?.status === 'plays' ? 'yes' : probe?.status === 'fails' ? 'no' : probe?.status === 'partial' ? 'partial' : null
  const agrees = predicted && measuredLevel ? predicted.verdict === measuredLevel : null

  return (
    <div className="panel">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-5 py-3">
        <p className="font-mono text-[11px] font-semibold uppercase tracking-[0.2em] text-mute">
          Measured, not estimated: live playback test on this device
        </p>
        <button onClick={onRerun} disabled={probing} className="btn-ghost disabled:opacity-50">
          {probing ? 'testing...' : 're-run test'}
        </button>
      </div>

      <div className="grid gap-6 px-5 py-5 sm:grid-cols-[200px_1fr]">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-mute">Result</p>
          <p className={`mt-1 font-mono text-3xl font-semibold tracking-tight ${probing ? 'text-mute' : probe ? STATUS_TEXT[probe.status].cls : 'text-mute'}`}>
            {probing ? 'TESTING' : probe ? STATUS_TEXT[probe.status].word : '\u2014'}
          </p>
          <p className="mt-2 text-xs leading-relaxed text-mute">
            {probing
              ? 'Handing the file to a real media element and forcing a decode (up to 6 s)...'
              : probe?.detail}
          </p>
        </div>

        <div>
          <dl>
            <Row label="This browser" value={probe?.browserName} />
            <Row label="MIME used" value={probe?.mime} />
            <Row label="canPlayType()" value={probe?.canPlay} />
            <Row label="Duration seen" value={probe?.duration ? fmtDuration(probe.duration) : undefined} />
            <Row label="Frame size seen" value={probe?.width && probe?.height ? fmtRes(probe.width, probe.height) : undefined} />
            <Row
              label="Seek + decode"
              value={probe?.seekOk === undefined ? undefined : probe.seekOk ? 'frame decoded after seek' : 'did not finish in time'}
            />
            <Row label="MediaError" value={probe?.errorCode ? `${probe.errorCode} (${probe.detail.split(':')[0]})` : undefined} />
          </dl>

          {predicted && measuredLevel && (
            <p className="mt-3 border-t border-line pt-3 text-xs leading-relaxed text-mute">
              Table estimate for {predicted.target.name}:{' '}
              <span className={`font-semibold ${STATUS[predicted.verdict].text}`}>{STATUS[predicted.verdict].label}</span>
              {' '}on a score of {predicted.score}/100. Measured here:{' '}
              <span className={`font-semibold ${STATUS_TEXT[probe!.status].cls}`}>{STATUS_TEXT[probe!.status].word}</span>.
              {agrees
                ? ' Estimate and measurement agree.'
                : ' Estimate and measurement differ; hardware decoding, OS codec packs and OS versions explain most differences, which is why this live test exists.'}
            </p>
          )}
        </div>
      </div>
    </div>
  )
}
