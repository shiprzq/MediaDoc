import { useCallback, useEffect, useRef, useState } from 'react'

const ACCEPT =
  'video/*,audio/*,.mkv,.mka,.ts,.m2ts,.mts,.vob,.wmv,.asf,.flv,.f4v,.ogv,.ogg,.oga,.opus,.3gp,.3g2,.m2v,.divx,.m4v,.m4b,.aif,.aiff,.caf,.wma,.ape,.wv,.rmvb,.wtv'

export default function Dropzone({ onFiles, busy }: { onFiles: (f: File[]) => void; busy: boolean }) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [drag, setDrag] = useState(false)
  const dragDepth = useRef(0)

  const pick = useCallback(
    (files: FileList | null) => {
      const list = files ? Array.from(files).filter((f) => f.size > 0) : []
      if (list.length > 0 && !busy) onFiles(list)
    },
    [busy, onFiles],
  )

  useEffect(() => {
    const onPaste = (e: ClipboardEvent) => {
      if (e.clipboardData?.files?.length) pick(e.clipboardData.files)
    }
    window.addEventListener('paste', onPaste)
    return () => window.removeEventListener('paste', onPaste)
  }, [pick])

  return (
    <div
      role="button"
      tabIndex={0}
      aria-label="Upload video or audio files for analysis"
      onClick={() => !busy && inputRef.current?.click()}
      onKeyDown={(e) => {
        if ((e.key === 'Enter' || e.key === ' ') && !busy) inputRef.current?.click()
      }}
      onDragEnter={(e) => {
        e.preventDefault()
        dragDepth.current++
        setDrag(true)
      }}
      onDragLeave={(e) => {
        e.preventDefault()
        dragDepth.current = Math.max(0, dragDepth.current - 1)
        if (dragDepth.current === 0) setDrag(false)
      }}
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault()
        dragDepth.current = 0
        setDrag(false)
        pick(e.dataTransfer.files)
      }}
      className={`w-full cursor-pointer border-2 border-dashed px-6 py-12 text-center sm:py-16 ${
        drag ? 'border-brand bg-[#fbeae8]' : 'border-ink/40 bg-surface hover:border-ink'
      } ${busy ? 'pointer-events-none opacity-50' : ''}`}
    >
      <input
        ref={inputRef}
        type="file"
        multiple
        accept={ACCEPT}
        className="hidden"
        onChange={(e) => {
          pick(e.target.files)
          e.target.value = ''
        }}
      />

      <p className="text-xl font-bold tracking-tight text-ink sm:text-2xl">
        {drag ? 'Release to analyze' : 'Drop video or audio files here'}
      </p>
      <p className="mt-2 text-sm text-mute">multiple files are analyzed one after another; pasting works too</p>
      <p className="mt-5">
        <span className="btn">Choose files</span>
      </p>
      <p className="mt-6 font-mono text-[11px] leading-relaxed tracking-wide text-mute">
        MP4 / MKV / MOV / AVI / WEBM / TS / WMV / FLV / 3GP / MP3 / FLAC / AAC / WAV / OGG / OPUS / WMA / AIFF
      </p>
      <p className="mt-3 text-xs text-mute">
        Files are read locally by the MediaInfo engine (WebAssembly). Nothing is uploaded, and analysis still
        works if you go offline after the page has loaded.
      </p>
    </div>
  )
}
