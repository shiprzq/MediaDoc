import Dropzone from './Dropzone'

const FACTS: [string, string][] = [
  ['Analysis engine', 'MediaInfo (WebAssembly)'],
  ['Targets checked', '10 browsers, OS players, TVs'],
  ['Bytes uploaded', '0 (runs fully offline-capable)'],
  ['Live test', 'Real playback attempt on this device'],
]

const STEPS: [string, string, string][] = [
  ['01', 'Drop a file', 'The file is opened with the browser File API. MediaInfo seeks through it and reads only the byte ranges it needs.'],
  ['02', 'Read the streams', 'Container, video and audio codecs, profiles, resolution, frame rate, bitrate, bit depth, HDR, subtitles, languages.'],
  ['03', 'Get verdicts and fixes', 'Support tables estimate playback on 10 targets, a live test measures this device, and ffmpeg commands fix what fails.'],
]

export default function Hero({
  onFiles, busy,
}: {
  onFiles: (f: File[]) => void
  busy: boolean
}) {
  return (
    <section id="top" className="border-b border-line">
      <div className="mx-auto max-w-6xl px-4 pb-16 pt-14 sm:px-6 sm:pt-20">
        <div className="grid items-end gap-10 lg:grid-cols-[1fr_320px]">
          <div>
            <h1 className="max-w-2xl text-5xl font-bold leading-[1.02] tracking-tight text-ink sm:text-7xl">
              Will this file play?
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-mute sm:text-lg">
              Drop a video or audio file. MediaDoc reads its container, codecs, resolution, bitrate, audio tracks
              and subtitles on your own machine, reports which browsers, phones and TVs can play it, explains
              every failure, and writes the ffmpeg command that fixes it.
            </p>
          </div>
          <dl>
            {FACTS.map(([k, val]) => (
              <div key={k} className="flex items-baseline justify-between gap-4 border-b border-line py-2.5 first:border-t">
                <dt className="font-mono text-[11px] uppercase tracking-[0.14em] text-mute">{k}</dt>
                <dd className="text-right font-mono text-xs font-medium text-ink">{val}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="mt-10">
          <Dropzone onFiles={onFiles} busy={busy} />
        </div>

        <div className="mt-14 grid gap-8 sm:grid-cols-3 sm:gap-6">
          {STEPS.map(([n, title, text]) => (
            <div key={n} className="border-t-2 border-ink pt-4">
              <p className="font-mono text-xs font-semibold text-brand">{n}</p>
              <p className="mt-1.5 text-sm font-semibold text-ink">{title}</p>
              <p className="mt-1.5 text-xs leading-relaxed text-mute">{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
