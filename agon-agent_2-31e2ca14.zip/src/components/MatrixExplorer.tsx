import { useState } from 'react'
import { DEVICES } from '../lib/devices'
import { STATUS } from '../lib/status'
import type { AudioCodecId, ContainerId, SupportLevel, VideoCodecId } from '../lib/types'
import { AUDIO_LABELS, CONTAINER_LABELS, VIDEO_LABELS } from '../lib/types'

interface Row<T extends string> {
  id: T
  sub?: string
}

const VIDEO_ROWS: Row<VideoCodecId>[] = [
  { id: 'h264', sub: 'AVC; the safe bet' },
  { id: 'hevc', sub: 'H.265; 4K standard' },
  { id: 'vp9', sub: 'YouTube' },
  { id: 'av1', sub: 'Royalty-free, new' },
  { id: 'vp8' },
  { id: 'mpeg2', sub: 'DVD / broadcast' },
  { id: 'mpeg4asp', sub: 'DivX / Xvid era' },
  { id: 'vc1', sub: 'WMV9 / Blu-ray' },
  { id: 'prores', sub: 'Editing codec' },
  { id: 'theora', sub: 'Legacy open codec' },
  { id: 'mjpeg' },
  { id: 'ffv1', sub: 'Archival' },
]

const AUDIO_ROWS: Row<AudioCodecId>[] = [
  { id: 'aac', sub: 'the safe bet' },
  { id: 'mp3' },
  { id: 'opus', sub: 'best low bitrate' },
  { id: 'vorbis' },
  { id: 'flac', sub: 'lossless' },
  { id: 'ac3', sub: 'Dolby Digital' },
  { id: 'eac3', sub: 'Dolby Digital+' },
  { id: 'dts' },
  { id: 'truehd', sub: 'lossless Blu-ray' },
  { id: 'pcm', sub: 'uncompressed' },
  { id: 'wma' },
  { id: 'alac', sub: 'Apple lossless' },
]

const CONTAINER_ROWS: Row<ContainerId>[] = [
  { id: 'mp4', sub: 'the safe bet' },
  { id: 'mkv' },
  { id: 'webm' },
  { id: 'mov', sub: 'QuickTime' },
  { id: 'avi', sub: 'legacy' },
  { id: 'ts', sub: 'broadcast / Blu-ray' },
  { id: 'wmv' },
  { id: 'ogg' },
  { id: 'mpegps', sub: 'DVD' },
  { id: 'flv', sub: 'Flash era' },
  { id: '3gp', sub: 'old phones' },
]

type TabId = 'video' | 'audio' | 'containers'

const TABS: { id: TabId; label: string }[] = [
  { id: 'video', label: 'Video codecs' },
  { id: 'audio', label: 'Audio codecs' },
  { id: 'containers', label: 'Containers' },
]

function Cell({ level, tooltip }: { level: SupportLevel; tooltip: string }) {
  return (
    <td className="px-1.5 py-1.5 text-center" title={tooltip}>
      <div className="flex justify-center">
        <span className="h-3.5 w-3.5" style={{ background: STATUS[level].hex }} />
      </div>
    </td>
  )
}

export default function MatrixExplorer() {
  const [tab, setTab] = useState<TabId>('video')

  const rows: { id: string; label: string; sub?: string }[] =
    tab === 'video'
      ? VIDEO_ROWS.map((r) => ({ ...r, label: VIDEO_LABELS[r.id] }))
      : tab === 'audio'
        ? AUDIO_ROWS.map((r) => ({ ...r, label: AUDIO_LABELS[r.id] }))
        : CONTAINER_ROWS.map((r) => ({ ...r, label: CONTAINER_LABELS[r.id] }))

  const lookup = (device: (typeof DEVICES)[number], rowId: string) => {
    const map = tab === 'video' ? device.video : tab === 'audio' ? device.audio : device.containers
    return (map as Record<string, { level: SupportLevel; note?: string } | undefined>)[rowId] ?? { level: 'no' as SupportLevel }
  }

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div className="flex gap-6">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`border-b-2 pb-1.5 text-sm font-semibold ${
                tab === t.id ? 'border-ink text-ink' : 'border-transparent text-mute hover:text-ink'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-4 font-mono text-[11px] text-mute">
          {(Object.keys(STATUS) as SupportLevel[]).map((k) => (
            <span key={k} className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5" style={{ background: STATUS[k].hex }} />
              {k === 'yes' ? 'Supported' : k === 'partial' ? 'Conditional' : 'No'}
            </span>
          ))}
        </div>
      </div>

      <div className="panel overflow-hidden">
        <div className="code-scroll overflow-x-auto">
          <table className="w-full min-w-[820px] border-collapse">
            <thead>
              <tr className="border-b-2 border-ink">
                <th className="sticky left-0 z-10 bg-surface px-4 py-3 text-left font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-mute">
                  {TABS.find((t) => t.id === tab)?.label}
                </th>
                {DEVICES.map((d) => (
                  <th key={d.id} className="px-1.5 py-3 text-center font-mono text-[10px] font-semibold uppercase tracking-wider text-ink">
                    {d.short}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id} className="border-b border-line last:border-b-0">
                  <td className="sticky left-0 z-10 bg-surface px-4 py-1.5">
                    <span className="block text-xs font-medium text-ink">{row.label}</span>
                    {row.sub && <span className="block font-mono text-[10px] text-mute">{row.sub}</span>}
                  </td>
                  {DEVICES.map((d) => {
                    const s = lookup(d, row.id)
                    return (
                      <Cell
                        key={d.id}
                        level={s.level}
                        tooltip={`${d.name}; ${row.label}: ${s.level === 'yes' ? 'supported' : s.level === 'partial' ? 'conditional' : 'not supported'}${s.note ? `; ${s.note}` : ''}`}
                      />
                    )
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="border-t border-line px-4 py-3 font-mono text-[11px] leading-relaxed text-mute">
          Simplified overview of current stable versions across {DEVICES.length} targets. Hardware, OS version and
          installed codec packs all matter. Hover a cell for the fine print, and test on the real device when it
          matters.
        </p>
      </div>
    </div>
  )
}
