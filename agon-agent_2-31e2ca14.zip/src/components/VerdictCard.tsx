import { useState } from 'react'
import type { TargetVerdict } from '../lib/types'
import { SEV, STATUS } from '../lib/status'

export default function VerdictCard({ v }: { v: TargetVerdict }) {
  const [open, setOpen] = useState(false)
  const meta = STATUS[v.verdict]

  return (
    <div className="panel flex flex-col">
      <div className="flex items-start justify-between gap-3 border-b border-line px-4 py-3">
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold text-ink">{v.target.name}</p>
          <p className="mt-0.5 text-[11px] text-mute">{v.target.blurb}</p>
        </div>
        <span className="inline-flex shrink-0 items-center gap-1.5 font-mono text-[10px] font-semibold uppercase tracking-wider">
          <span className="h-2.5 w-2.5" style={{ background: meta.hex }} />
          <span className={meta.text}>{meta.label}</span>
        </span>
      </div>

      <p className="px-4 py-3 text-xs leading-relaxed text-mute">{v.headline}</p>

      {open && (
        <ul className="space-y-2.5 border-t border-line px-4 py-3">
          {v.issues.length === 0 && <li className="text-xs text-mute">No issues detected on this target.</li>}
          {v.issues.map((issue, i) => {
            const sev = SEV[issue.severity]
            return (
              <li key={i} className="flex items-start gap-2">
                <span className="mt-1 h-2 w-2 shrink-0" style={{ background: sev.hex }} />
                <div className="min-w-0">
                  <p className="text-xs leading-relaxed text-ink">
                    <span className="font-mono text-[10px] uppercase tracking-wider text-mute">
                      {issue.component}:{' '}
                    </span>
                    {issue.message}
                  </p>
                  {issue.detail && <p className="mt-0.5 text-[11px] leading-relaxed text-mute">{issue.detail}</p>}
                  {issue.fix && (
                    <p className="mt-0.5 text-[11px] leading-relaxed text-ink">
                      <span className="font-semibold">Fix: </span>{issue.fix}
                    </p>
                  )}
                </div>
              </li>
            )
          })}
        </ul>
      )}

      {v.issues.length > 0 && (
        <button
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          className="mt-auto flex items-center justify-between border-t border-line px-4 py-2 text-left font-mono text-[11px] uppercase tracking-wider text-mute hover:bg-paper hover:text-ink"
        >
          <span>{v.issues.length} note{v.issues.length === 1 ? '' : 's'}</span>
          <span>{open ? '[ hide ]' : '[ show ]'}</span>
        </button>
      )}
    </div>
  )
}
