import { useCallback, useEffect, useRef, useState } from 'react'
import { fmtBitrate, fmtBytes, fmtDuration } from '../lib/format'
import { DEVICE_CATEGORIES } from '../lib/devices'
import { probeFile } from '../lib/probe'
import type { ProbeResult } from '../lib/probe'
import { downloadText, reportToText } from '../lib/reportText'
import { STATUS } from '../lib/status'
import type { FileResult } from '../lib/types'
import CoverageStrip from './CoverageStrip'
import DiagnosisPanel from './DiagnosisPanel'
import PrescriptionPanel from './PrescriptionPanel'
import ProbePanel from './ProbePanel'
import { SectionHeading } from './Section'
import TracksPanel from './TracksPanel'
import VerdictCard from './VerdictCard'

function Meta({ label, value }: { label: string; value?: string }) {
  if (!value) return null
  return (
    <div className="min-w-0">
      <dt className="font-mono text-[10px] uppercase tracking-[0.16em] text-mute">{label}</dt>
      <dd className="mt-0.5 truncate font-mono text-sm font-medium text-ink" title={value}>{value}</dd>
    </div>
  )
}

export default function ReportView({
  results, active, onSelect, onReset,
}: {
  results: FileResult[]
  active: number
  onSelect: (i: number) => void
  onReset: () => void
}) {
  const entry = results[active]
  const report = entry?.ok ? entry.report : null

  const [probe, setProbe] = useState<ProbeResult | null>(null)
  const [probing, setProbing] = useState(false)
  const probeId = useRef(0)

  const runProbe = useCallback(() => {
    if (!entry?.ok) return
    const file = entry.file
    const hasVideo = entry.report.media.video.length > 0
    const id = ++probeId.current
    setProbe(null)
    setProbing(true)
    probeFile(file, hasVideo)
      .then((r) => { if (probeId.current === id) { setProbe(r); setProbing(false) } })
      .catch(() => { if (probeId.current === id) setProbing(false) })
  }, [entry])

  useEffect(() => {
    probeId.current++
    setProbe(null)
    setProbing(false)
    runProbe()
  }, [runProbe])

  if (!entry) return null

  return (
    <div className="space-y-16">
      {/* File switcher for batch runs */}
      {results.length > 1 && (
        <div className="panel">
          <p className="border-b border-line px-4 py-2.5 font-mono text-[11px] font-semibold uppercase tracking-[0.2em] text-mute">
            {results.length} files analyzed; select one
          </p>
          <div className="code-scroll overflow-x-auto">
            {results.map((r, i) => {
              const name = r.ok ? r.report.media.fileName : r.name
              const isActive = i === active
              return (
                <button
                  key={`${name}-${i}`}
                  onClick={() => onSelect(i)}
                  className={`flex w-full items-center gap-4 border-b border-line px-4 py-2.5 text-left last:border-b-0 ${
                    isActive ? 'bg-ink text-surface' : 'hover:bg-paper'
                  }`}
                >
                  <span className={`font-mono text-xs ${isActive ? 'text-surface/60' : 'text-mute'}`}>
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <span className="min-w-0 flex-1 truncate font-mono text-xs font-medium">{name}</span>
                  {r.ok ? (
                    <>
                      <span className={`hidden font-mono text-[11px] sm:inline ${isActive ? 'text-surface/70' : 'text-mute'}`}>
                        {r.report.media.containerLabel}
                      </span>
                      <span className={`hidden font-mono text-[11px] md:inline ${isActive ? 'text-surface/70' : 'text-mute'}`}>
                        {r.report.playsCount}/{r.report.verdicts.length} play
                      </span>
                      <span className="flex gap-0.5">
                        {r.report.verdicts.map((v) => (
                          <span key={v.target.id} className="h-3 w-3" style={{ background: STATUS[v.verdict].hex }} />
                        ))}
                      </span>
                    </>
                  ) : (
                    <span className={`font-mono text-[11px] ${isActive ? 'text-red-300' : 'text-bad'}`}>unreadable</span>
                  )}
                </button>
              )
            })}
          </div>
        </div>
      )}

      {!entry.ok ? (
        <div className="panel border-l-4 border-l-bad px-5 py-6">
          <p className="font-mono text-[11px] font-semibold uppercase tracking-[0.2em] text-bad">Unreadable file</p>
          <p className="mt-2 break-all font-mono text-sm font-medium text-ink">{entry.name}</p>
          <p className="mt-2 max-w-xl text-sm leading-relaxed text-mute">{entry.error}</p>
          <button onClick={onReset} className="btn mt-5">Analyze other files</button>
        </div>
      ) : (
        <>
          {/* ---------- File header ---------- */}
          <section>
            <div className="border-t-2 border-ink pt-4">
              <p className="font-mono text-[11px] font-semibold uppercase tracking-[0.2em] text-mute">File under test</p>
              <h2 className="mt-2 break-all font-mono text-lg font-semibold text-ink sm:text-xl" title={report!.media.fileName}>
                {report!.media.fileName}
              </h2>
              {report!.media.encrypted && (
                <p className="mt-2 inline-block bg-bad px-2 py-0.5 font-mono text-[11px] font-semibold uppercase tracking-wider text-surface">
                  DRM protected
                </p>
              )}
            </div>

            <div className="panel mt-6 grid gap-x-8 gap-y-5 px-5 py-6 sm:grid-cols-3 lg:grid-cols-6">
              <Meta label="Size" value={fmtBytes(report!.media.fileSize)} />
              <Meta label="Container" value={report!.media.containerLabel} />
              <Meta label="Duration" value={fmtDuration(report!.media.duration)} />
              <Meta label="Overall bitrate" value={fmtBitrate(report!.media.overallBitrate)} />
              <Meta
                label="Streams"
                value={`${report!.media.video.length}V + ${report!.media.audio.length}A + ${report!.media.subs.length}S`}
              />
              <Meta
                label="Scan"
                value={`${fmtBytes(report!.scan.bytesRead)} read, ${report!.scan.msElapsed} ms`}
              />
            </div>
          </section>

          {/* ---------- Verdict summary + live test ---------- */}
          <section>
            <SectionHeading
              eyebrow="Estimated compatibility"
              title="Where it should play"
              sub="From codec and container support tables for current stable platforms. The panel below it measures this device for real."
            />

            <div className="panel mb-6 px-5 py-5">
              <div className="flex flex-wrap items-center gap-x-8 gap-y-4">
                <p className="font-mono text-3xl font-semibold tracking-tight text-ink">
                  {report!.playsCount}<span className="text-mute">/{report!.verdicts.length}</span>
                  <span className="ml-3 align-middle font-mono text-[11px] font-normal uppercase tracking-[0.18em] text-mute">
                    targets play it
                  </span>
                </p>
                <div>
                  <div className="flex gap-1">
                    {report!.verdicts.map((v) => (
                      <span
                        key={v.target.id}
                        title={`${v.target.name}: ${STATUS[v.verdict].label}`}
                        className="h-5 w-5 border border-ink/10"
                        style={{ background: STATUS[v.verdict].hex }}
                      />
                    ))}
                  </div>
                  <p className="mt-2 font-mono text-[11px] text-mute">
                    {report!.playsCount} play / {report!.partialCount} partial / {report!.failCount} fail
                    {' '}· estimate {report!.score}/100
                  </p>
                </div>
                <div className="ml-auto flex gap-2">
                  <button
                    onClick={() => downloadText(`${report!.media.fileName}.mediadoc.txt`, reportToText(report!))}
                    className="btn-ghost"
                  >
                    Download report (.txt)
                  </button>
                  <button onClick={onReset} className="btn-ghost">Analyze other files</button>
                </div>
              </div>
            </div>

            <ProbePanel probe={probe} probing={probing} report={report!} onRerun={runProbe} />
          </section>

          {/* ---------- Tracks ---------- */}
          <section>
            <SectionHeading
              eyebrow="Inside the file"
              title="Streams, exactly as parsed"
              sub="Container, codecs, resolution, bitrate, audio tracks and subtitles, read by MediaInfo in your browser."
            />
            <TracksPanel media={report!.media} />
          </section>

          {/* ---------- Per-target verdicts ---------- */}
          <section>
            <SectionHeading
              eyebrow="Target by target"
              title="The estimate, per device"
              sub="Ten real-world targets checked against the container and every stream. Open a card for the reasoning."
            />
            <div className="space-y-8">
              {DEVICE_CATEGORIES.map((cat) => {
                const list = report!.verdicts.filter((v) => v.target.category === cat)
                if (list.length === 0) return null
                return (
                  <div key={cat}>
                    <p className="mb-3 font-mono text-[11px] font-semibold uppercase tracking-[0.18em] text-mute">{cat}</p>
                    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                      {list.map((v) => (
                        <VerdictCard key={v.target.id} v={v} />
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>
            <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-1.5 font-mono text-[11px] text-mute">
              {(Object.keys(STATUS) as Array<keyof typeof STATUS>).map((k) => (
                <span key={k} className="flex items-center gap-1.5">
                  <span className="h-2.5 w-2.5" style={{ background: STATUS[k].hex }} />
                  {STATUS[k].label}
                </span>
              ))}
              <span>; verdicts assume current stable versions of each platform</span>
            </div>
          </section>

          {/* ---------- Diagnosis ---------- */}
          <section>
            <SectionHeading
              eyebrow="Diagnosis"
              title={report!.diagnosis.length > 0 ? 'Why it fails, and what to do' : 'No problems found'}
              sub="Every issue detected across all targets, deduplicated and ranked by severity."
            />
            <DiagnosisPanel items={report!.diagnosis} />
          </section>

          {/* ---------- Prescription ---------- */}
          <section>
            <SectionHeading
              eyebrow="Fix"
              title="Conversion settings"
              sub="Ready-to-run ffmpeg commands chosen for this exact file, from lossless remuxes to full universal conversions."
            />
            <PrescriptionPanel prescriptions={report!.prescriptions} />
          </section>

          {/* ---------- Raw data ---------- */}
          <section>
            <details className="panel group">
              <summary className="flex cursor-pointer items-center justify-between px-5 py-4">
                <span className="font-mono text-[11px] font-semibold uppercase tracking-[0.2em] text-mute">
                  Raw MediaInfo data and scan log (unedited)
                </span>
                <span className="font-mono text-sm text-mute">
                  <span className="group-open:hidden">[ + ]</span>
                  <span className="hidden group-open:inline">[ - ]</span>
                </span>
              </summary>
              <div className="space-y-4 border-t border-line px-5 py-5">
                <div>
                  <p className="mb-2 font-mono text-[11px] text-mute">
                    Byte ranges read: {fmtBytes(report!.scan.bytesRead)} of {fmtBytes(report!.media.fileSize)} across{' '}
                    {report!.scan.segments.length} segments in {report!.scan.msElapsed} ms
                  </p>
                  <CoverageStrip segments={report!.scan.segments} total={report!.media.fileSize} />
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => downloadText(`${report!.media.fileName}.mediainfo.json`, report!.raw, 'application/json')}
                    className="btn-ghost"
                  >
                    Download JSON
                  </button>
                  <button
                    onClick={() => downloadText(`${report!.media.fileName}.mediadoc.txt`, reportToText(report!))}
                    className="btn-ghost"
                  >
                    Download report (.txt)
                  </button>
                </div>
                <pre className="code-scroll max-h-96 overflow-auto border border-line bg-paper p-4 font-mono text-[11px] leading-relaxed text-ink">
                  {report!.raw}
                </pre>
              </div>
            </details>
          </section>
        </>
      )}
    </div>
  )
}
