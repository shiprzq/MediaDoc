import { fmtBitrate, fmtChannels, fmtFps, fmtRes, fmtSampleRate } from '../lib/format'
import type { NormalizedMedia } from '../lib/types'

function Spec({ label, value }: { label: string; value?: string }) {
  if (!value || value === '\u2014') return null
  return (
    <div className="min-w-0 border-t border-line pt-2">
      <dt className="font-mono text-[10px] uppercase tracking-wider text-mute">{label}</dt>
      <dd className="mt-0.5 truncate font-mono text-xs text-ink" title={value}>{value}</dd>
    </div>
  )
}

function TrackHeader({ label, codec, chips }: { label: string; codec: string; chips?: (string | undefined)[] }) {
  return (
    <div className="mb-3 flex flex-wrap items-baseline gap-x-3 gap-y-1">
      <span className="font-mono text-[11px] font-semibold uppercase tracking-[0.18em] text-mute">{label}</span>
      <span className="font-mono text-sm font-semibold text-ink">{codec}</span>
      {(chips ?? []).filter(Boolean).map((c) => (
        <span key={c} className="border border-line bg-paper px-1.5 py-0.5 font-mono text-[10px] text-mute">
          {c}
        </span>
      ))}
    </div>
  )
}

export default function TracksPanel({ media }: { media: NormalizedMedia }) {
  return (
    <div className="panel divide-y divide-line">
      {media.video.map((v) => (
        <div key={`v${v.index}`} className="px-5 py-5">
          <TrackHeader
            label={`Video${media.video.length > 1 ? ` track ${v.index + 1}` : ''}`}
            codec={v.codecLabel}
            chips={[v.profile, v.hdr ? `HDR: ${v.hdr}` : undefined, v.codecId ? `tag: ${v.codecId}` : undefined]}
          />
          <dl className="grid grid-cols-2 gap-x-6 gap-y-3 sm:grid-cols-4 lg:grid-cols-5">
            <Spec label="Resolution" value={fmtRes(v.width, v.height)} />
            <Spec label="Frame rate" value={v.fps ? `${fmtFps(v.fps)}${v.fpsMode === 'VFR' ? ' (variable)' : ''}` : undefined} />
            <Spec label="Bit rate" value={fmtBitrate(v.bitrate)} />
            <Spec label="Bit depth" value={v.bitDepth ? `${v.bitDepth}-bit` : undefined} />
            <Spec label="Chroma" value={v.chroma} />
            <Spec label="Scan" value={v.scanType} />
            <Spec label="Color primaries" value={v.colorPrimaries} />
            <Spec label="Transfer" value={v.transfer} />
          </dl>
        </div>
      ))}

      {media.audio.map((a) => (
        <div key={`a${a.index}`} className="px-5 py-5">
          <TrackHeader
            label={`Audio${media.audio.length > 1 ? ` track ${a.index + 1}` : ''}`}
            codec={a.codecLabel}
            chips={[a.language, a.title ? `\u201c${a.title}\u201d` : undefined]}
          />
          <dl className="grid grid-cols-2 gap-x-6 gap-y-3 sm:grid-cols-4 lg:grid-cols-5">
            <Spec label="Channels" value={fmtChannels(a.channels, a.channelLayout)} />
            <Spec label="Sample rate" value={fmtSampleRate(a.sampleRate)} />
            <Spec label="Bit depth" value={a.bitDepth ? `${a.bitDepth}-bit` : undefined} />
            <Spec label="Bit rate" value={fmtBitrate(a.bitrate)} />
          </dl>
        </div>
      ))}

      {media.subs.map((t) => {
        const browserHostile = ['pgs', 'vobsub', 'ass'].includes(t.codec)
        return (
          <div key={`s${t.index}`} className="px-5 py-5">
            <TrackHeader
              label={`Subtitles${media.subs.length > 1 ? ` track ${t.index + 1}` : ''}`}
              codec={t.codecLabel}
              chips={[
                t.language,
                t.forced ? 'forced' : undefined,
                browserHostile ? 'not rendered by browsers' : undefined,
              ]}
            />
          </div>
        )
      })}

      {media.video.length === 0 && media.audio.length === 0 && (
        <p className="px-5 py-5 text-sm text-mute">No media tracks detected.</p>
      )}
    </div>
  )
}
