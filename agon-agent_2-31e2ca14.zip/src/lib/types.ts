export type SupportLevel = 'yes' | 'partial' | 'no'

export interface Support {
  level: SupportLevel
  note?: string
}

export const Y = (note?: string): Support => ({ level: 'yes', note })
export const P = (note?: string): Support => ({ level: 'partial', note })
export const N = (note?: string): Support => ({ level: 'no', note })

export type ContainerId =
  | 'mp4' | 'mov' | 'mkv' | 'webm' | 'avi' | 'wmv' | 'flv' | 'ts' | 'mpegps'
  | 'ogg' | '3gp' | 'm4a' | 'mp3' | 'wav' | 'flac' | 'aiff' | 'caf' | 'wma'
  | 'ape' | 'wv' | 'unknown'

export type VideoCodecId =
  | 'h264' | 'hevc' | 'vp8' | 'vp9' | 'av1' | 'mpeg2' | 'mpeg1' | 'mpeg4asp'
  | 'vc1' | 'wmv' | 'theora' | 'prores' | 'h263' | 'mjpeg' | 'dv' | 'ffv1' | 'unknown'

export type AudioCodecId =
  | 'aac' | 'mp3' | 'mp2' | 'opus' | 'vorbis' | 'flac' | 'ac3' | 'eac3' | 'ac4'
  | 'dts' | 'dtshd' | 'truehd' | 'pcm' | 'wma' | 'alac' | 'amr' | 'ape' | 'wv' | 'unknown'

export type SubCodecId =
  | 'subrip' | 'ass' | 'webvtt' | 'movtext' | 'pgs' | 'vobsub' | 'cea' | 'unknown'

export const CONTAINER_LABELS: Record<ContainerId, string> = {
  mp4: 'MP4',
  mov: 'QuickTime MOV',
  mkv: 'Matroska (MKV)',
  webm: 'WebM',
  avi: 'AVI',
  wmv: 'ASF / WMV',
  flv: 'Flash Video (FLV)',
  ts: 'MPEG Transport Stream',
  mpegps: 'MPEG Program Stream',
  ogg: 'Ogg',
  '3gp': '3GPP',
  m4a: 'M4A / AAC',
  mp3: 'MP3 file',
  wav: 'WAV',
  flac: 'FLAC file',
  aiff: 'AIFF',
  caf: 'CAF (CoreAudio)',
  wma: 'WMA',
  ape: "Monkey's Audio",
  wv: 'WavPack',
  unknown: 'Unknown container',
}

export const VIDEO_LABELS: Record<VideoCodecId, string> = {
  h264: 'H.264 / AVC',
  hevc: 'H.265 / HEVC',
  vp8: 'VP8',
  vp9: 'VP9',
  av1: 'AV1',
  mpeg2: 'MPEG-2 Video',
  mpeg1: 'MPEG-1 Video',
  mpeg4asp: 'MPEG-4 ASP (DivX/Xvid)',
  vc1: 'VC-1 / WMV9',
  wmv: 'Windows Media Video 7/8',
  theora: 'Theora',
  prores: 'Apple ProRes',
  h263: 'H.263',
  mjpeg: 'Motion JPEG',
  dv: 'DV',
  ffv1: 'FFV1',
  unknown: 'Unknown video codec',
}

export const AUDIO_LABELS: Record<AudioCodecId, string> = {
  aac: 'AAC',
  mp3: 'MP3',
  mp2: 'MPEG Audio Layer II',
  opus: 'Opus',
  vorbis: 'Vorbis',
  flac: 'FLAC',
  ac3: 'Dolby Digital (AC-3)',
  eac3: 'Dolby Digital Plus (E-AC-3)',
  ac4: 'Dolby AC-4',
  dts: 'DTS',
  dtshd: 'DTS-HD / DTS:X',
  truehd: 'Dolby TrueHD',
  pcm: 'PCM / LPCM',
  wma: 'Windows Media Audio',
  alac: 'Apple Lossless (ALAC)',
  amr: 'AMR',
  ape: "Monkey's Audio",
  wv: 'WavPack',
  unknown: 'Unknown audio codec',
}

export const SUB_LABELS: Record<SubCodecId, string> = {
  subrip: 'SubRip (SRT)',
  ass: 'ASS / SSA (styled)',
  webvtt: 'WebVTT',
  movtext: 'MPEG-4 Timed Text',
  pgs: 'PGS (Blu-ray bitmap)',
  vobsub: 'VobSub (DVD bitmap)',
  cea: 'CEA-608/708 captions',
  unknown: 'Unknown subtitle format',
}

export interface VideoTrack {
  index: number
  codec: VideoCodecId
  codecLabel: string
  profile?: string
  codecId?: string
  width?: number
  height?: number
  fps?: number
  fpsMode?: string
  bitrate?: number
  bitDepth?: number
  chroma?: string
  colorPrimaries?: string
  transfer?: string
  hdr?: string
  scanType?: string
}

export interface AudioTrack {
  index: number
  codec: AudioCodecId
  codecLabel: string
  profile?: string
  channels?: number
  channelLayout?: string
  sampleRate?: number
  bitDepth?: number
  bitrate?: number
  language?: string
  title?: string
}

export interface SubTrack {
  index: number
  codec: SubCodecId
  codecLabel: string
  language?: string
  title?: string
  forced?: boolean
}

export interface NormalizedMedia {
  fileName: string
  fileSize: number
  container: ContainerId
  containerLabel: string
  duration?: number
  overallBitrate?: number
  title?: string
  encrypted: boolean
  video: VideoTrack[]
  audio: AudioTrack[]
  subs: SubTrack[]
}

export type DeviceCategory = 'Browsers' | 'Mobile' | 'Desktop' | 'Living room'

export interface DeviceProfile {
  id: string
  name: string
  short: string
  category: DeviceCategory
  blurb: string
  icon: string
  containers: Partial<Record<ContainerId, Support>>
  video: Partial<Record<VideoCodecId, Support>>
  audio: Partial<Record<AudioCodecId, Support>>
  subs: Partial<Record<SubCodecId, Support>>
}

export type Severity = 'error' | 'warning' | 'info'

export interface Issue {
  severity: Severity
  component: string
  message: string
  detail?: string
  fix?: string
}

export interface TargetVerdict {
  target: DeviceProfile
  verdict: SupportLevel
  score: number
  headline: string
  issues: Issue[]
}

export interface DiagnosisItem {
  severity: Severity
  component: string
  title: string
  detail?: string
  fix?: string
  affects: string[]
}

export type PrescriptionKind = 'remux' | 'transcode' | 'efficient' | 'audio-fix' | 'optimize' | 'none'

export interface Prescription {
  id: string
  kind: PrescriptionKind
  title: string
  subtitle: string
  command?: string
  notes: string[]
  recommended: boolean
}

export interface ScanSegment {
  offset: number
  length: number
}

export interface ScanStats {
  msElapsed: number
  bytesRead: number
  segments: ScanSegment[]
}

export interface AnalysisReport {
  media: NormalizedMedia
  verdicts: TargetVerdict[]
  score: number
  playsCount: number
  partialCount: number
  failCount: number
  diagnosis: DiagnosisItem[]
  prescriptions: Prescription[]
  scan: ScanStats
  /** Pretty-printed raw MediaInfo track data, exactly as parsed */
  raw: string
}

export type FileResult =
  | { ok: true; file: File; report: AnalysisReport }
  | { ok: false; name: string; size: number; error: string }
