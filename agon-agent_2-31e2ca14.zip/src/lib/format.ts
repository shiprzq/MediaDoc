export function fmtBytes(n?: number): string {
  if (n == null || !Number.isFinite(n)) return '—'
  if (n < 1024) return `${Math.round(n)} B`
  const units = ['KB', 'MB', 'GB', 'TB']
  let v = n / 1024
  let i = 0
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024
    i++
  }
  return `${v >= 100 ? Math.round(v) : v.toFixed(1)} ${units[i]}`
}

export function fmtBitrate(bps?: number): string {
  if (!bps || !Number.isFinite(bps)) return '—'
  if (bps >= 1_000_000) return `${(bps / 1_000_000).toFixed(bps >= 10_000_000 ? 0 : 1)} Mb/s`
  return `${Math.round(bps / 1000)} kb/s`
}

export function fmtDuration(sec?: number): string {
  if (sec == null || !Number.isFinite(sec)) return '—'
  const s = Math.round(sec)
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const r = s % 60
  if (h) return `${h} h ${String(m).padStart(2, '0')} min`
  if (m) return `${m} min ${String(r).padStart(2, '0')} s`
  return `${r} s`
}

export function resTag(w?: number, h?: number): string | null {
  if (!w || !h) return null
  if (h >= 3800) return '8K'
  if (h >= 2000) return '4K UHD'
  if (h >= 1400) return '1440p'
  if (h >= 1000) return '1080p'
  if (h >= 700) return '720p'
  return 'SD'
}

export function fmtRes(w?: number, h?: number): string {
  if (!w || !h) return '—'
  const tag = resTag(w, h)
  return `${w.toLocaleString()} × ${h.toLocaleString()}${tag ? ` · ${tag}` : ''}`
}

export function fmtFps(f?: number): string {
  if (!f) return '—'
  const pretty = Number.isInteger(f) ? String(f) : f.toFixed(3).replace(/0+$/, '').replace(/\.$/, '')
  return `${pretty} fps`
}

export function fmtChannels(ch?: number, layout?: string): string {
  if (layout) return layout
  if (!ch) return '—'
  if (ch === 1) return 'Mono'
  if (ch === 2) return 'Stereo'
  if (ch === 6) return '5.1 surround'
  if (ch === 8) return '7.1 surround'
  return `${ch} channels`
}

export function fmtSampleRate(sr?: number): string {
  if (!sr) return '—'
  return `${(sr / 1000).toFixed(sr % 1000 === 0 ? 0 : 1)} kHz`
}
