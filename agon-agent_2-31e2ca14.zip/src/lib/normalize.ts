import type {
  AudioCodecId, AudioTrack, ContainerId, NormalizedMedia, SubCodecId, SubTrack,
  VideoCodecId, VideoTrack,
} from './types'
import { AUDIO_LABELS, CONTAINER_LABELS, SUB_LABELS, VIDEO_LABELS } from './types'

/** MediaInfo (object mode) returns most values as strings, but numeric fields
 *  like Duration, BitRate, Channels, Width, Height arrive as real numbers. */
export type Field = string | number | undefined

export interface RawTrack {
  '@type'?: string
  [key: string]: string | number | undefined
}

const num = (v?: Field): number | undefined => {
  if (v == null || v === '') return undefined
  const n = typeof v === 'number' ? v : parseFloat(String(v).replace(/[^\d.-]/g, ''))
  return Number.isFinite(n) ? n : undefined
}

const str = (v?: Field): string | undefined => {
  if (v == null) return undefined
  const s = String(v).trim()
  return s === '' ? undefined : s
}

const low = (v?: Field): string => str(v)?.toLowerCase() ?? ''

const LANGS: Record<string, string> = {
  en: 'English', ja: 'Japanese', es: 'Spanish', fr: 'French', de: 'German', it: 'Italian',
  pt: 'Portuguese', ru: 'Russian', ko: 'Korean', zh: 'Chinese', ar: 'Arabic', hi: 'Hindi',
  nl: 'Dutch', sv: 'Swedish', pl: 'Polish', tr: 'Turkish', da: 'Danish', fi: 'Finnish',
  no: 'Norwegian', cs: 'Czech', th: 'Thai', vi: 'Vietnamese', id: 'Indonesian', und: 'Undetermined',
}

function prettyLang(v?: Field): string | undefined {
  const s = str(v)
  if (!s) return undefined
  const low = s.toLowerCase()
  if (low.length <= 3) return LANGS[low] ?? s.toUpperCase()
  return s
}

function extOf(name: string): string {
  return (name.match(/\.([^.]+)$/)?.[1] ?? '').toLowerCase()
}

function detectContainer(g: RawTrack | undefined, fileName: string, hasVideo: boolean): ContainerId {
  const f = low(g?.Format)
  const prof = low(g?.Format_Profile)
  const cid = low(g?.CodecID)
  const e = extOf(fileName)

  if (f.includes('matroska')) return 'mkv'
  if (f.includes('webm')) return 'webm'
  if (f.includes('mpeg-4') || f === 'isom') {
    if (prof.includes('quicktime') || cid === 'qt' || cid === 'qt  ' || e === 'mov' || e === 'qt') return 'mov'
    if (prof.includes('3gpp') || e === '3gp' || e === '3g2') return '3gp'
    if (!hasVideo && (e === 'm4a' || e === 'm4b' || e === 'aac')) return 'm4a'
    return 'mp4'
  }
  if (f.includes('quicktime')) return 'mov'
  if (f === 'avi') return 'avi'
  if (f.includes('windows media')) return 'wmv'
  if (f.includes('flash video')) return 'flv'
  if (f.includes('mpeg-ts') || f.includes('bdav') || f.includes('blu-ray')) return 'ts'
  if (f.includes('mpeg-ps')) return 'mpegps'
  if (f === 'ogg') return 'ogg'
  if (f.includes('mpeg audio')) return 'mp3'
  if (f.includes('wave')) return 'wav'
  if (f === 'flac') return 'flac'
  if (f.includes('aiff')) return 'aiff'
  if (f.includes('coreaudio') || f === 'caf') return 'caf'
  if (f.includes("monkey")) return 'ape'
  if (f.includes('wavpack')) return 'wv'

  const byExt: Record<string, ContainerId> = {
    mp4: 'mp4', m4v: 'mp4', mov: 'mov', qt: 'mov', mkv: 'mkv', mka: 'mkv', webm: 'webm',
    avi: 'avi', wmv: 'wmv', asf: 'wmv', flv: 'flv', f4v: 'flv', ts: 'ts', m2ts: 'ts', mts: 'ts',
    mpg: 'mpegps', mpeg: 'mpegps', vob: 'mpegps', ogv: 'ogg', ogg: 'ogg', oga: 'ogg', opus: 'ogg',
    '3gp': '3gp', '3g2': '3gp', mp3: 'mp3', wav: 'wav', wave: 'wav', flac: 'flac',
    m4a: 'm4a', aac: 'm4a', aiff: 'aiff', aif: 'aiff', caf: 'caf', wma: 'wma', ape: 'ape', wv: 'wv',
  }
  return byExt[e] ?? 'unknown'
}

function detectVideo(t: RawTrack): { id: VideoCodecId; label: string } {
  const f = low(t.Format)
  const cid = low(t.CodecID)
  const ver = low(t.Format_Version)

  if (f.includes('avc') || f === 'h.264' || f === 'h264' || cid.includes('avc1') || cid.includes('avc3') || cid.includes('v_mpeg4/iso/avc')) return { id: 'h264', label: VIDEO_LABELS.h264 }
  if (f.includes('hevc') || f.includes('h.265') || cid.includes('hvc1') || cid.includes('hev1') || cid.includes('v_mpegh')) return { id: 'hevc', label: VIDEO_LABELS.hevc }
  if (f.includes('vp9') || cid.includes('v_vp9') || cid.includes('vp09')) return { id: 'vp9', label: VIDEO_LABELS.vp9 }
  if (f.includes('vp8') || cid.includes('v_vp8')) return { id: 'vp8', label: VIDEO_LABELS.vp8 }
  if (f.includes('av1') || cid.includes('av01') || cid.includes('v_av1')) return { id: 'av1', label: VIDEO_LABELS.av1 }
  if (f.includes('mpeg video') || f.includes('mpeg-1') || f.includes('mpeg-2')) {
    if (ver.includes('2') || cid.includes('mp2v') || cid.includes('v_mpeg2')) return { id: 'mpeg2', label: VIDEO_LABELS.mpeg2 }
    return { id: 'mpeg1', label: VIDEO_LABELS.mpeg1 }
  }
  if (f.includes('mpeg-4 visual') || /xvid|divx|dx50|fmp4|mp4v|3ivx/.test(cid)) return { id: 'mpeg4asp', label: VIDEO_LABELS.mpeg4asp }
  if (f.includes('vc-1') || cid.includes('wmv3') || cid.includes('vc1') || cid.includes('wvc1')) return { id: 'vc1', label: VIDEO_LABELS.vc1 }
  if (cid.includes('wmv1') || cid.includes('wmv2') || (f.includes('windows media') && f.includes('video'))) return { id: 'wmv', label: VIDEO_LABELS.wmv }
  if (f.includes('theora')) return { id: 'theora', label: VIDEO_LABELS.theora }
  if (f.includes('prores') || cid.includes('apch') || cid.includes('apcn') || cid.includes('apcs') || cid.includes('apco') || cid.includes('ap4h')) return { id: 'prores', label: VIDEO_LABELS.prores }
  if (f.includes('h.263') || f.includes('h263') || cid.includes('s263')) return { id: 'h263', label: VIDEO_LABELS.h263 }
  if (f.includes('mjpeg') || f === 'jpeg') return { id: 'mjpeg', label: VIDEO_LABELS.mjpeg }
  if (f === 'dv' || f.startsWith('dv ')) return { id: 'dv', label: VIDEO_LABELS.dv }
  if (f.includes('ffv1')) return { id: 'ffv1', label: VIDEO_LABELS.ffv1 }
  return { id: 'unknown', label: str(t.Format) ?? 'Unknown video codec' }
}

function detectAudio(t: RawTrack): { id: AudioCodecId; label: string } {
  const f = low(t.Format)
  const cid = low(t.CodecID)
  const prof = low(t.Format_Profile)
  const comm = str(t.Format_Commercial_IfAny) ?? str(t.Format_Commercial)

  if (comm?.toLowerCase().includes('truehd') || f.includes('truehd') || f.includes('mlp fba')) return { id: 'truehd', label: comm ?? AUDIO_LABELS.truehd }
  if (comm?.toLowerCase().includes('dts-hd') || comm?.toLowerCase().includes('dts:x') || (f.includes('dts') && (/\bma\b|xll|\bx\b/.test(prof)))) return { id: 'dtshd', label: comm ?? AUDIO_LABELS.dtshd }
  if (f.includes('dts') || cid.includes('a_dts')) return { id: 'dts', label: comm ?? 'DTS' }
  if (f.includes('e-ac-3') || f.includes('eac3') || cid.includes('ec-3') || cid.includes('a_eac3') || comm?.toLowerCase().includes('digital plus')) return { id: 'eac3', label: comm ?? AUDIO_LABELS.eac3 }
  if (f.includes('ac-4') || cid.includes('ac-4')) return { id: 'ac4', label: AUDIO_LABELS.ac4 }
  if (f.includes('ac-3') || f.includes('ac3') || cid.includes('ac-3') || cid.includes('a_ac3') || comm?.toLowerCase().includes('dolby digital')) return { id: 'ac3', label: comm ?? AUDIO_LABELS.ac3 }
  if (f.includes('aac') || cid.includes('mp4a') || cid.includes('a_aac')) {
    const p = str(t.Format_Profile)
    return { id: 'aac', label: p ? `AAC ${p}` : 'AAC' }
  }
  if (f.includes('mpeg audio') || cid.includes('a_mpeg')) {
    if (prof.includes('layer 2')) return { id: 'mp2', label: AUDIO_LABELS.mp2 }
    if (prof.includes('layer 1')) return { id: 'mp2', label: 'MPEG Audio Layer I' }
    return { id: 'mp3', label: 'MP3' }
  }
  if (f.includes('opus') || cid.includes('a_opus')) return { id: 'opus', label: AUDIO_LABELS.opus }
  if (f.includes('vorbis') || cid.includes('a_vorbis')) return { id: 'vorbis', label: AUDIO_LABELS.vorbis }
  if (f.includes('flac') || cid.includes('a_flac')) return { id: 'flac', label: AUDIO_LABELS.flac }
  if (f.includes('pcm') || f.includes('lpcm') || cid.includes('a_pcm') || f.includes('adpcm')) return { id: 'pcm', label: f.includes('adpcm') ? 'ADPCM' : AUDIO_LABELS.pcm }
  if (f.includes('windows media') || cid.includes('wma')) return { id: 'wma', label: AUDIO_LABELS.wma }
  if (f.includes('alac')) return { id: 'alac', label: AUDIO_LABELS.alac }
  if (f.includes('amr')) return { id: 'amr', label: AUDIO_LABELS.amr }
  if (f.includes("monkey")) return { id: 'ape', label: AUDIO_LABELS.ape }
  if (f.includes('wavpack')) return { id: 'wv', label: AUDIO_LABELS.wv }
  return { id: 'unknown', label: str(t.Format) ?? 'Unknown audio codec' }
}

function detectSub(t: RawTrack): { id: SubCodecId; label: string } {
  const f = low(t.Format)
  const cid = low(t.CodecID)
  if (f.includes('ass') || f.includes('ssa') || cid.includes('s_text/ass') || cid.includes('s_text/ssa') || cid.includes('s_ssa')) return { id: 'ass', label: SUB_LABELS.ass }
  if (f.includes('webvtt') || cid.includes('wvtt')) return { id: 'webvtt', label: SUB_LABELS.webvtt }
  if (f.includes('pgs') || cid.includes('s_hdmv')) return { id: 'pgs', label: SUB_LABELS.pgs }
  if (f.includes('vobsub') || cid.includes('s_vobsub') || f === 'rle' || cid.includes('s_text/dvd') || cid.includes('mp4s')) return { id: 'vobsub', label: SUB_LABELS.vobsub }
  if (cid.includes('tx3g') || f.includes('timed text') || cid.includes('stpp')) return { id: 'movtext', label: SUB_LABELS.movtext }
  if (f.includes('eia-6') || f.includes('eia-7') || f.includes('cea')) return { id: 'cea', label: SUB_LABELS.cea }
  if (f.includes('utf-8') || f.includes('utf8') || f.includes('subrip') || cid.includes('s_text/utf8')) return { id: 'subrip', label: SUB_LABELS.subrip }
  return { id: 'unknown', label: str(t.Format) ?? 'Unknown subtitles' }
}

function videoProfile(t: RawTrack): string | undefined {
  const p = str(t.Format_Profile)
  const lvl = str(t.Format_Level)
  if (p && lvl && !p.includes('@') && /^\d/.test(lvl)) return `${p}@L${lvl}`
  return p ?? undefined
}

export function normalizeTracks(tracks: RawTrack[], fileName: string, fileSize: number): NormalizedMedia {
  const general = tracks.find((t) => t['@type'] === 'General')
  const videoRaw = tracks.filter((t) => t['@type'] === 'Video')
  const audioRaw = tracks.filter((t) => t['@type'] === 'Audio')
  const textRaw = tracks.filter((t) => t['@type'] === 'Text')

  const encrypted = [general, ...videoRaw, ...audioRaw].some((t) => {
    const enc = str(t?.Encryption)
    return !!enc && !/^(no|not encrypted)?$/i.test(enc)
  })

  const video: VideoTrack[] = videoRaw.map((t, i) => {
    const det = detectVideo(t)
    const transfer = str(t.transfer_characteristics)
    const hdrCommercial = str(t.HDR_Format_Commercial_IfAny) ?? str(t.HDR_Format_Commercial)
    const hdrRaw = str(t.HDR_Format)
    const isHdr = hdrCommercial ?? (transfer === 'PQ' || transfer === 'HLG' ? hdrRaw ?? `HDR (${transfer})` : undefined)
    return {
      index: i,
      codec: det.id,
      codecLabel: det.label,
      profile: videoProfile(t),
      codecId: str(t.CodecID),
      width: num(t.Width),
      height: num(t.Height),
      fps: num(t.FrameRate),
      fpsMode: str(t.FrameRate_Mode),
      bitrate: num(t.BitRate),
      bitDepth: num(t.BitDepth),
      chroma: str(t.ChromaSubsampling),
      colorPrimaries: str(t.colour_primaries),
      transfer,
      hdr: isHdr,
      scanType: str(t.ScanType),
    }
  })

  const audio: AudioTrack[] = audioRaw.map((t, i) => {
    const det = detectAudio(t)
    return {
      index: i,
      codec: det.id,
      codecLabel: det.label,
      profile: str(t.Format_Profile),
      channels: num(t.Channels),
      channelLayout: str(t.ChannelLayout) ?? str(t.ChannelLayout_Original),
      sampleRate: num(t.SamplingRate),
      bitDepth: num(t.BitDepth),
      bitrate: num(t.BitRate),
      language: prettyLang(t.Language),
      title: str(t.Title),
    }
  })

  const subs: SubTrack[] = textRaw.map((t, i) => {
    const det = detectSub(t)
    return {
      index: i,
      codec: det.id,
      codecLabel: det.label,
      language: prettyLang(t.Language),
      title: str(t.Title),
      forced: t.Forced === 'Yes',
    }
  })

  const container = detectContainer(general, fileName, video.length > 0)

  return {
    fileName,
    fileSize,
    container,
    containerLabel: CONTAINER_LABELS[container],
    duration: num(general?.Duration),
    overallBitrate: num(general?.OverallBitRate),
    title: str(general?.Title),
    encrypted,
    video,
    audio,
    subs,
  }
}
