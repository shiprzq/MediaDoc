import mediaInfoFactory from 'mediainfo.js'
import { buildDiagnosis, evaluateAll } from './evaluate'
import { normalizeTracks } from './normalize'
import type { RawTrack } from './normalize'
import { buildPrescriptions } from './prescription'
import type { AnalysisReport, NormalizedMedia, ScanSegment, ScanStats } from './types'

export type ProgressCb = (bytesScanned: number, total: number, segments: ScanSegment[]) => void

interface MediaInfoInstance {
  analyzeData: (
    getSize: () => number,
    readChunk: (size: number, offset: number) => Promise<Uint8Array>,
  ) => Promise<unknown>
  close: () => void
}

let miPromise: Promise<MediaInfoInstance> | null = null

function getMediaInfo(): Promise<MediaInfoInstance> {
  if (!miPromise) {
    miPromise = mediaInfoFactory({
      format: 'object',
      full: true,
      locateFile: () => '/mediainfo.wasm',
    } as never) as unknown as Promise<MediaInfoInstance>
  }
  return miPromise
}

function toReport(media: NormalizedMedia, tracks: RawTrack[], scan: ScanStats): AnalysisReport {
  const verdicts = evaluateAll(media)
  const score = Math.round(verdicts.reduce((s, v) => s + v.score, 0) / verdicts.length)
  const playsCount = verdicts.filter((v) => v.verdict === 'yes').length
  const partialCount = verdicts.filter((v) => v.verdict === 'partial').length
  const failCount = verdicts.filter((v) => v.verdict === 'no').length
  return {
    media,
    verdicts,
    score,
    playsCount,
    partialCount,
    failCount,
    diagnosis: buildDiagnosis(verdicts),
    prescriptions: buildPrescriptions(media),
    scan,
    raw: JSON.stringify(tracks, null, 2),
  }
}

export async function analyzeFile(file: File, onProgress: ProgressCb): Promise<AnalysisReport> {
  let mi: MediaInfoInstance
  try {
    mi = await getMediaInfo()
  } catch {
    throw new Error('The MediaInfo engine failed to load. Check your connection and refresh the page.')
  }

  const segments: ScanSegment[] = []
  const started = performance.now()

  let result: unknown
  try {
    result = await mi.analyzeData(
      () => file.size,
      async (chunkSize: number, offset: number) => {
        const length = Math.max(0, Math.min(chunkSize, file.size - offset))
        const buf = await file.slice(offset, offset + chunkSize).arrayBuffer()
        segments.push({ offset, length })
        onProgress(Math.min(offset + chunkSize, file.size), file.size, segments)
        return new Uint8Array(buf)
      },
    )
  } catch {
    try { mi.close() } catch { /* noop */ }
    miPromise = null
    throw new Error("Couldn't read this file. It may be corrupted or not a media file at all.")
  }

  const scan: ScanStats = {
    msElapsed: Math.max(1, Math.round(performance.now() - started)),
    bytesRead: segments.reduce((a, s) => a + s.length, 0),
    segments,
  }

  const tracks = (result as { media?: { track?: RawTrack[] } } | null)?.media?.track
  if (!Array.isArray(tracks) || tracks.length === 0) {
    throw new Error('No media streams found. Is this really a video or audio file?')
  }

  const media = normalizeTracks(tracks, file.name, file.size)
  if (media.video.length === 0 && media.audio.length === 0) {
    throw new Error('I found a container, but no video or audio streams inside it.')
  }
  return toReport(media, tracks, scan)
}
