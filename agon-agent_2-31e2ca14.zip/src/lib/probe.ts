export type ProbeStatus = 'plays' | 'partial' | 'fails' | 'unknown'

export interface ProbeResult {
  status: ProbeStatus
  detail: string
  browserName: string
  targetId?: string
  mime: string
  canPlay: string
  duration?: number
  width?: number
  height?: number
  seekOk?: boolean
  errorCode?: number
}

const EXT_MIME: Record<string, string> = {
  mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/quicktime', mkv: 'video/x-matroska',
  webm: 'video/webm', avi: 'video/x-msvideo', wmv: 'video/x-ms-asf', flv: 'video/x-flv',
  ts: 'video/mp2t', m2ts: 'video/mp2t', mts: 'video/mp2t', mpg: 'video/mpeg', mpeg: 'video/mpeg',
  '3gp': 'video/3gpp', '3g2': 'video/3gpp2', ogv: 'video/ogg',
  mp3: 'audio/mpeg', m4a: 'audio/mp4', aac: 'audio/aac', flac: 'audio/flac', wav: 'audio/wav',
  ogg: 'audio/ogg', oga: 'audio/ogg', opus: 'audio/ogg', wma: 'audio/x-ms-wma',
  aiff: 'audio/aiff', aif: 'audio/aiff', caf: 'audio/x-caf',
}

export function currentBrowser(): { name: string; targetId?: string } {
  const ua = navigator.userAgent
  const v = (re: RegExp) => ua.match(re)?.[1]
  if (/iPhone|iPad|iPod/.test(ua)) {
    const ver = v(/OS ([\d_]+)/)?.replace(/_/g, '.')
    return { name: `Safari on iOS${ver ? ` ${ver}` : ''}`, targetId: 'ios' }
  }
  if (/Edg\//.test(ua)) return { name: `Edge ${v(/Edg\/([\d.]+)/) ?? ''}`.trim(), targetId: 'edge' }
  if (/OPR\//.test(ua)) return { name: `Opera ${v(/OPR\/([\d.]+)/) ?? ''}`.trim(), targetId: 'chrome' }
  if (/Firefox\//.test(ua)) return { name: `Firefox ${v(/Firefox\/([\d.]+)/) ?? ''}`.trim(), targetId: 'firefox' }
  if (/Chrome\//.test(ua)) {
    const ver = v(/Chrome\/([\d.]+)/) ?? ''
    if (/Android/.test(ua)) return { name: `Chrome ${ver} on Android`.trim(), targetId: 'android' }
    return { name: `Chrome ${ver}`.trim(), targetId: 'chrome' }
  }
  if (/Safari\//.test(ua)) return { name: `Safari ${v(/Version\/([\d.]+)/) ?? ''}`.trim(), targetId: 'safari' }
  return { name: 'Unrecognized browser' }
}

const MEDIA_ERROR_TEXT: Record<number, string> = {
  1: 'MEDIA_ERR_ABORTED: loading was aborted.',
  2: 'MEDIA_ERR_NETWORK: network error (unexpected for a local file).',
  3: 'MEDIA_ERR_DECODE: the file is corrupt or uses a codec this browser cannot decode.',
  4: 'MEDIA_ERR_SRC_NOT_SUPPORTED: this browser refuses the container or codec.',
}

function raceEvent(
  el: HTMLMediaElement,
  okEvent: string,
  ms: number,
  start: () => void,
): Promise<'ok' | 'error' | 'timeout'> {
  return new Promise((resolve) => {
    let done = false
    const cleanup = () => {
      window.clearTimeout(timer)
      el.removeEventListener(okEvent, onOk)
      el.removeEventListener('error', onBad)
    }
    const finish = (r: 'ok' | 'error' | 'timeout') => {
      if (done) return
      done = true
      cleanup()
      resolve(r)
    }
    const onOk = () => finish('ok')
    const onBad = () => finish('error')
    const timer = window.setTimeout(() => finish('timeout'), ms)
    el.addEventListener(okEvent, onOk)
    el.addEventListener('error', onBad)
    start()
  })
}

/**
 * Empirical playback test: hands the actual file to a real media element and
 * forces a decode by seeking. No heuristics; this measures what this device
 * really does with the bytes.
 */
export async function probeFile(file: File, hasVideo: boolean): Promise<ProbeResult> {
  const browser = currentBrowser()
  const ext = (file.name.match(/\.([^.]+)$/)?.[1] ?? '').toLowerCase()
  const mime = file.type || EXT_MIME[ext] || ''
  const el = document.createElement(hasVideo ? 'video' : 'audio') as HTMLVideoElement
  el.muted = true
  el.preload = 'auto'
  const canPlay = mime ? el.canPlayType(mime) : ''
  const url = URL.createObjectURL(file)
  const base = {
    browserName: browser.name,
    targetId: browser.targetId,
    mime: mime || '(no MIME type known)',
    canPlay: canPlay === '' ? '"" (empty string: browser says no)' : `"${canPlay}"`,
  }

  try {
    const loaded = await raceEvent(el, 'loadedmetadata', 6000, () => {
      el.src = url
    })

    if (loaded === 'timeout') {
      return { ...base, status: 'unknown', detail: 'No response from the media element within 6 s.' }
    }
    if (loaded === 'error') {
      const code = el.error?.code
      return {
        ...base,
        status: 'fails',
        errorCode: code,
        detail: (code && MEDIA_ERROR_TEXT[code]) || 'The media element rejected the file.',
      }
    }

    const duration = Number.isFinite(el.duration) ? el.duration : undefined
    const width = el.videoWidth || undefined
    const height = el.videoHeight || undefined

    let seekOk: boolean | undefined
    if (duration && duration > 0.5) {
      const target = Math.min(1, duration / 2)
      const seeked = await raceEvent(el, 'seeked', 4000, () => {
        try { el.currentTime = target } catch { /* noop */ }
      })
      seekOk = seeked === 'ok'
    }

    if (seekOk === false) {
      return {
        ...base, duration, width, height, seekOk,
        status: 'partial',
        detail: 'Container and metadata parsed, but decoding a frame at the seek position did not finish in time.',
      }
    }
    return {
      ...base, duration, width, height, seekOk,
      status: 'plays',
      detail: seekOk
        ? 'Container parsed and at least one frame decoded after a seek.'
        : 'Container and metadata parsed (file too short for a seek test).',
    }
  } finally {
    el.removeAttribute('src')
    el.load()
    URL.revokeObjectURL(url)
  }
}
