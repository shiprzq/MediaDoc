import { isHi10P } from './evaluate'
import type { NormalizedMedia, Prescription } from './types'

const stripExt = (n: string) => n.replace(/\.[^.]+$/, '')
const extOf = (n: string) => (n.match(/\.([^.]+)$/)?.[1] ?? 'mkv').toLowerCase()

export function buildPrescriptions(media: NormalizedMedia): Prescription[] {
  const out: Prescription[] = []
  const v = media.video[0]
  const isAudioOnly = !v
  const input = media.fileName
  const base = stripExt(media.fileName)
  const mp4Out = `${base}.mp4`
  const hi10 = isHi10P(v)
  const bitDepth10 = (v?.bitDepth ?? 8) >= 10

  // ---------------- Audio-only files ----------------
  if (isAudioOnly) {
    const a = media.audio[0]
    const alreadyUniversal =
      a && (a.codec === 'aac' || a.codec === 'mp3') && ['m4a', 'mp3', 'mp4'].includes(media.container)
    if (alreadyUniversal) {
      out.push({
        id: 'none', kind: 'none', recommended: true,
        title: 'No conversion needed',
        subtitle: `${media.containerLabel} with ${a?.codecLabel} already plays on virtually every device, browser and car stereo made in the last 15 years.`,
        notes: ['Share the file as-is', 'If you need smaller files for streaming, see the AAC re-encode below'],
      })
    }
    out.push({
      id: 'm4a', kind: 'transcode', recommended: !alreadyUniversal,
      title: 'Universal audio (M4A / AAC)',
      subtitle: 'AAC in an M4A wrapper plays absolutely everywhere: every browser, phone, TV, car and game console.',
      command: `ffmpeg -i "${input}" -vn -c:a aac -b:a 256k -movflags +faststart "${base}.m4a"`,
      notes: [
        '256 kb/s AAC is transparent for music; use 128k for voice',
        ...(a && ((a.sampleRate ?? 0) > 48000 || (a.bitDepth ?? 16) > 16)
          ? ['Hi-res source: add -af aresample=48000 if a picky device still chokes']
          : []),
      ],
    })
    out.push({
      id: 'mp3', kind: 'transcode', recommended: false,
      title: 'Maximum-compatibility MP3',
      subtitle: 'For genuinely ancient hardware; old car stereos, cheap MP3 players, embedded systems.',
      command: `ffmpeg -i "${input}" -vn -c:a libmp3lame -q:a 2 "${base}.mp3"`,
      notes: ['-q:a 2 is ~190 kb/s VBR; the sweet spot for quality vs. size'],
    })
    return out
  }

  // ---------------- Video files ----------------
  const audioOkUniversal = media.audio.every((a) =>
    (a.codec === 'aac' && !/he-aac/i.test(a.profile ?? '')) || a.codec === 'mp3',
  )
  const universalVideo = v.codec === 'h264' && !hi10 && (v.bitDepth ?? 8) <= 8
  const fullyUniversal = media.container === 'mp4' && universalVideo && audioOkUniversal
  const canRemuxMp4 = media.container !== 'mp4' && universalVideo && audioOkUniversal
  const textSubsOnly = media.subs.every((t) => ['subrip', 'ass', 'webvtt', 'movtext'].includes(t.codec))

  if (fullyUniversal) {
    out.push({
      id: 'none', kind: 'none', recommended: true,
      title: 'No conversion needed',
      subtitle: 'MP4 + H.264 (8-bit) + AAC is the universal combination; this file already plays on everything in the test panel.',
      notes: ['Share it as-is', 'The faststart optimization below only matters if you host it on the web'],
    })
    out.push({
      id: 'faststart', kind: 'optimize', recommended: false,
      title: 'Optimize for web streaming',
      subtitle: 'Moves the MP4 metadata to the front so playback starts instantly in browsers. Lossless, takes seconds.',
      command: `ffmpeg -i "${input}" -c copy -movflags +faststart "${base}.web.mp4"`,
      notes: ['Only useful when hosting the file yourself; YouTube/socials do this automatically'],
    })
  }

  if (canRemuxMp4) {
    out.push({
      id: 'remux', kind: 'remux', recommended: true,
      title: 'Remux to MP4 (no re-encode)',
      subtitle: 'Your codecs are already fine; only the container is wrong. This just repackages the streams: lossless and done in seconds.',
      command: `ffmpeg -i "${input}" -map 0:v:0 -map 0:a? -c copy -movflags +faststart "${mp4Out}"`,
      notes: [
        'Zero quality loss; the video and audio bits are copied verbatim',
        '+faststart moves metadata to the front for instant web playback',
        ...(media.subs.length > 0
          ? [textSubsOnly
              ? 'Subtitles: add -map 0:s:0? -c:s mov_text to carry them over (styling is simplified)'
              : 'Image-based subtitles (PGS/VobSub) cannot live in MP4; extract them or burn them in']
          : []),
      ],
    })
  }

  const hevcNeedsTag = v.codec === 'hevc' && (v.codecId ?? '').toLowerCase() === 'hev1'
  if (v.codec === 'hevc' && ['mkv', 'mov', 'ts', 'avi'].includes(media.container) && !hi10) {
    out.push({
      id: 'remux-hevc', kind: 'remux', recommended: false,
      title: `Remux to MP4 (keeps HEVC)${hevcNeedsTag ? ' + fix hvc1 tag' : ''}`,
      subtitle: hevcNeedsTag
        ? 'Two birds, one remux: a friendlier container plus the hvc1 tag that Apple devices demand. Lossless.'
        : 'Same HEVC quality in a friendlier MP4 wrapper. Still requires modern hardware to decode.',
      command: `ffmpeg -i "${input}" -map 0:v:0 -map 0:a? -c copy -tag:v hvc1 -movflags +faststart "${mp4Out}"`,
      notes: [
        '-tag:v hvc1 is what Safari, iOS and QuickTime require for HEVC',
        'HEVC still won\'t play in Firefox or on older hardware; use the H.264 conversion for that',
      ],
    })
  }

  if (!fullyUniversal) {
    const audioMap = media.audio.length ? ' -map 0:a:0?' : ''
    const audioCodec = media.audio.length ? ' -c:a aac -b:a 192k' : ''
    const subMap = media.subs.length && textSubsOnly ? ' -map 0:s:0? -c:s mov_text' : ''
    out.push({
      id: 'universal', kind: 'transcode', recommended: !canRemuxMp4,
      title: 'Universal MP4 (H.264 + AAC)',
      subtitle: "The 'plays anywhere' build: browsers, phones, TVs, consoles, projectors; everything since ~2010.",
      command: `ffmpeg -i "${input}" -map 0:v:0${audioMap} -c:v libx264 -preset medium -crf 20 -pix_fmt yuv420p${audioCodec}${subMap} -movflags +faststart "${mp4Out}"`,
      notes: [
        'CRF 20 is visually transparent; lower = better quality + bigger file (18–23 is the sane range)',
        '-pix_fmt yuv420p forces 8-bit color, which every hardware decoder understands',
        '+faststart moves metadata to the front so web playback starts instantly',
        ...(hi10 ? ['Converts the 10-bit H.264 (Hi10P) stream into standard 8-bit that devices can actually decode'] : []),
        ...(v.hdr ? [`Source is HDR (${v.hdr}); this conversion tone-maps it to SDR; the HEVC option preserves HDR`] : []),
        ...(media.subs.length > 0 && !textSubsOnly ? ['Image-based subtitles (PGS/VobSub) cannot be converted to text; extract them or burn them in with the subtitles filter'] : []),
        ...((v.width ?? 0) > 1920 ? ['To cap at 1080p for older TVs, add: -vf scale=1920:-2'] : []),
      ],
    })
  }

  const exoticAudio =
    media.audio.length > 0 &&
    media.audio.every((a) => ['dts', 'dtshd', 'truehd', 'wma', 'vorbis', 'ape', 'wv', 'pcm', 'unknown'].includes(a.codec))
  if (exoticAudio) {
    const sameExt = ['mp4', 'mov', 'ts'].includes(media.container) ? extOf(input) : 'mkv'
    out.push({
      id: 'audio-fix', kind: 'audio-fix', recommended: fullyUniversal ? false : !canRemuxMp4 && universalVideo,
      title: 'Keep the video, fix the sound',
      subtitle: "The classic 'plays on my PC but silent on the TV' cure. Video is copied untouched (seconds, not hours); only the soundtrack becomes Dolby Digital.",
      command: `ffmpeg -i "${input}" -map 0:v:0 -map 0:a:0 -c:v copy -c:a ac3 -b:a 640k "${base}.tv-audio.${sameExt}"`,
      notes: [
        'AC-3 at 640 kb/s keeps full 5.1 surround and plays on every TV and soundbar ever made',
        'Smaller alternative: -c:a eac3 -b:a 448k (Dolby Digital Plus, most 2015+ TVs)',
        'For browsers specifically, prefer AAC: -c:a aac -b:a 192k',
      ],
    })
  }

  const wantsEfficient = v.codec !== 'hevc' && !hi10 && ((v.width ?? 0) >= 1920 || bitDepth10)
  if (wantsEfficient) {
    out.push({
      id: 'hevc', kind: 'efficient', recommended: false,
      title: 'Half the size (HEVC / H.265)',
      subtitle: 'Roughly 50% smaller at the same quality. Great for Apple devices, modern TVs and Windows 11; not for old hardware.',
      command: `ffmpeg -i "${input}" -map 0:v:0${media.audio.length ? ' -map 0:a:0?' : ''} -c:v libx265 -preset medium -crf 24${bitDepth10 ? ' -pix_fmt yuv420p10le' : ''} -tag:v hvc1${media.audio.length ? ' -c:a aac -b:a 160k' : ''} "${base}.hevc.mp4"`,
      notes: [
        '-tag:v hvc1 keeps Safari, iOS and QuickTime happy',
        ...(bitDepth10 ? ['Keeps 10-bit color (yuv420p10le) for HDR or graded content'] : []),
        'Encoding is slow; -preset fast halves the wait at a small quality cost',
      ],
    })
  }

  return out.sort((a, b) => Number(b.recommended) - Number(a.recommended))
}
