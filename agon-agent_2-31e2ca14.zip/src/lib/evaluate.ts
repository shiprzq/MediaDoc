import { DEVICES } from './devices'
import type {
  DeviceProfile, DiagnosisItem, Issue, NormalizedMedia, Support, SupportLevel,
  TargetVerdict, VideoTrack,
} from './types'
import { N } from './types'

const clampScore = (n: number) => Math.max(0, Math.min(100, Math.round(n)))

export function isHi10P(v?: Pick<VideoTrack, 'codec' | 'bitDepth' | 'profile'>): boolean {
  if (!v || v.codec !== 'h264') return false
  return (v.bitDepth ?? 8) >= 10 || /high\s*10/i.test(v.profile ?? '')
}

export function evaluateAll(media: NormalizedMedia): TargetVerdict[] {
  return DEVICES.map((d) => evaluateTarget(d, media))
}

function containerFix(media: NormalizedMedia): string {
  return media.video.length > 0
    ? 'Repackage or convert to MP4 (H.264 + AAC); see the prescription below'
    : 'Convert to M4A (AAC) or MP3; see the prescription below'
}

function videoFix(media: NormalizedMedia): string | undefined {
  const v = media.video[0]
  if (isHi10P(v)) return 'Re-encode to standard 8-bit H.264; 10-bit H.264 only plays in software players (VLC, mpv)'
  if (v?.codec === 'hevc') return 'For guaranteed playback, convert to H.264; or keep HEVC and accept that some browsers refuse it'
  return 'Convert the video to H.264 in an MP4 container for universal playback'
}

function audioFix(): string {
  return 'Convert the soundtrack to AAC (universal) or AC-3 (TVs); the video can be copied untouched'
}

function evaluateTarget(d: DeviceProfile, media: NormalizedMedia): TargetVerdict {
  const issues: Issue[] = []
  let score = 100
  let hard = false
  const isAudioOnly = media.video.length === 0

  if (media.encrypted) {
    issues.push({ severity: 'error', component: 'DRM', message: 'This file is encrypted (DRM-protected) and only plays inside its licensed app' })
    hard = true
  }

  // ---- Container ----
  const cs: Support = d.containers[media.container] ?? N(`Doesn't recognize the ${media.containerLabel} container`)
  if (cs.level === 'no') {
    issues.push({
      severity: 'error', component: 'Container',
      message: `Can't open the ${media.containerLabel} container`,
      detail: cs.note, fix: containerFix(media),
    })
    hard = true
  } else if (cs.level === 'partial') {
    issues.push({ severity: 'warning', component: 'Container', message: cs.note ?? 'Container support is limited' })
    score -= 20
  }

  // ---- Video ----
  const v0 = media.video[0]
  const hi10 = isHi10P(v0)
  for (const v of media.video) {
    let vs: Support | undefined = d.video[v.codec]
    let noteOverride: string | undefined
    if (hi10) {
      vs = N()
      noteOverride = '10-bit H.264 (Hi10P) has no hardware decoder support; browsers, phones and TVs all refuse it'
    }
    const hev1Tagged = v.codec === 'hevc' && (v.codecId ?? '').toLowerCase() === 'hev1'
    if (hev1Tagged && (d.id === 'safari' || d.id === 'ios' || d.id === 'mac')) {
      vs = N()
      noteOverride = 'This HEVC stream is tagged "hev1"; Apple players require the "hvc1" tag'
    }
    vs ??= N()
    if (vs.level === 'no') {
      issues.push({
        severity: 'error', component: 'Video',
        message: noteOverride ?? vs.note ?? `Can't decode ${v.codecLabel}`,
          fix: hev1Tagged ? 'Lossless fix: ffmpeg -i input -c copy -tag:v hvc1 output.mp4' : videoFix(media),
      })
      hard = true
    } else if (vs.level === 'partial') {
      issues.push({ severity: 'warning', component: 'Video', message: noteOverride ?? vs.note ?? `${v.codecLabel} support is conditional` })
      score -= 25
    }
  }

  if (v0) {
    if ((v0.width ?? 0) > 3840 || (v0.height ?? 0) > 2160) {
      issues.push({ severity: 'warning', component: 'Video', message: 'Above-4K resolution exceeds most hardware decoder limits' })
      score -= 10
    }
    if (v0.fpsMode === 'VFR' && (d.id === 'tv' || d.id === 'cast' || d.id === 'mac')) {
      issues.push({ severity: 'info', component: 'Video', message: 'Variable frame rate (VFR) can cause stutter or audio drift on TVs and QuickTime' })
      score -= 3
    }
    if (v0.hdr && ['chrome', 'firefox', 'edge', 'windows', 'android'].includes(d.id)) {
      issues.push({ severity: 'info', component: 'Video', message: `${v0.hdr} video needs an HDR display; on SDR screens colors can look washed out` })
      score -= 2
    }
    if (v0.scanType === 'Interlaced' && d.category === 'Browsers') {
      issues.push({ severity: 'info', component: 'Video', message: "Interlaced video; browsers don't deinterlace, so motion may show combing artifacts" })
      score -= 2
    }
    if ((v0.fps ?? 0) > 60) {
      issues.push({ severity: 'info', component: 'Video', message: `${Math.round(v0.fps ?? 0)} fps exceeds the 60 fps ceiling of many decoders and TVs` })
      score -= 2
    }
  }

  // ---- Audio ----
  if (media.audio.length > 0) {
    const supports = media.audio.map((a) => d.audio[a.codec] ?? N())
    if (supports.every((s) => s.level === 'no')) {
      const a0 = media.audio[0]
      if (isAudioOnly) {
        issues.push({ severity: 'error', component: 'Audio', message: supports[0].note ?? `Can't decode ${a0.codecLabel}`, fix: audioFix() })
        hard = true
      } else {
        issues.push({ severity: 'warning', component: 'Audio', message: `${supports[0].note ?? `${a0.codecLabel} isn't supported`}; the video will play, but silently`, fix: audioFix() })
        score -= 35
      }
    } else {
      if (supports.some((s) => s.level === 'no')) {
        issues.push({ severity: 'info', component: 'Audio', message: 'At least one audio track is unsupported here and will be skipped' })
        score -= 5
      }
      const p = supports.find((s) => s.level === 'partial')
      if (p) {
        issues.push({ severity: 'warning', component: 'Audio', message: p.note ?? 'Audio support is conditional' })
        score -= 10
      }
    }
    const hires = media.audio.some((a) => (a.sampleRate ?? 0) > 48000 || (a.bitDepth ?? 16) > 16)
    if (hires) {
      issues.push({ severity: 'info', component: 'Audio', message: 'Hi-res audio (above 16-bit / 48 kHz) may be downsampled or ignored by the device' })
      score -= 1
    }
  }

  // ---- Subtitles ----
  for (const t of media.subs) {
    const ss: Support = d.subs[t.codec] ?? N()
    if (ss.level === 'no') {
      issues.push({ severity: 'info', component: 'Subtitles', message: ss.note ?? `${t.codecLabel} subtitles won't display here` })
      score -= 2
    } else if (ss.level === 'partial') {
      issues.push({ severity: 'info', component: 'Subtitles', message: ss.note ?? 'Subtitle support is limited' })
      score -= 1
    }
  }

  score = clampScore(score)
  if (hard) score = Math.min(score, 10)
  const verdict: SupportLevel = hard ? 'no' : score >= 85 ? 'yes' : score >= 50 ? 'partial' : 'no'
  const firstErr = issues.find((i) => i.severity === 'error')
  const firstWarn = issues.find((i) => i.severity === 'warning')
  const headline = firstErr?.message ?? firstWarn?.message ?? issues[0]?.message ?? 'No issues detected on this target'
  return { target: d, verdict, score, headline, issues }
}

const SEV_RANK: Record<Issue['severity'], number> = { error: 0, warning: 1, info: 2 }

export function buildDiagnosis(verdicts: TargetVerdict[]): DiagnosisItem[] {
  const map = new Map<string, DiagnosisItem>()
  for (const v of verdicts) {
    for (const i of v.issues) {
      const key = `${i.severity}|${i.component}|${i.message}`
      const ex = map.get(key)
      if (ex) ex.affects.push(v.target.short)
      else map.set(key, { severity: i.severity, component: i.component, title: i.message, detail: i.detail, fix: i.fix, affects: [v.target.short] })
    }
  }
  return [...map.values()]
    .sort((a, b) => SEV_RANK[a.severity] - SEV_RANK[b.severity] || b.affects.length - a.affects.length)
    .slice(0, 9)
}
