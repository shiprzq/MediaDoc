import type { Severity, SupportLevel } from './types'

export const STATUS: Record<SupportLevel, { label: string; hex: string; text: string }> = {
  yes: { label: 'Plays', hex: '#16a34a', text: 'text-ok' },
  partial: { label: 'Partial', hex: '#d97706', text: 'text-warn' },
  no: { label: "Won't play", hex: '#dc2626', text: 'text-bad' },
}

export const SEV: Record<Severity, { label: string; hex: string; text: string }> = {
  error: { label: 'Blocker', hex: '#dc2626', text: 'text-bad' },
  warning: { label: 'Warning', hex: '#d97706', text: 'text-warn' },
  info: { label: 'Note', hex: '#1b1b18', text: 'text-ink' },
}
