import { fmtBitrate, fmtBytes, fmtDuration } from './format'
import type { AnalysisReport } from './types'

const VERDICT_WORD = { yes: 'PLAYS', partial: 'PARTIAL', no: 'FAILS' } as const

export function reportToText(r: AnalysisReport): string {
  const m = r.media
  const L: string[] = []
  L.push('MEDIADOC COMPATIBILITY REPORT')
  L.push(`Generated: ${new Date().toISOString()}`)
  L.push('')
  L.push('FILE')
  L.push(`  Name: ${m.fileName}`)
  L.push(`  Size: ${fmtBytes(m.fileSize)}`)
  L.push(`  Container: ${m.containerLabel}`)
  L.push(`  Duration: ${fmtDuration(m.duration)}`)
  L.push(`  Overall bitrate: ${fmtBitrate(m.overallBitrate)}`)
  m.video.forEach((v, i) =>
    L.push(`  Video ${i + 1}: ${v.codecLabel}${v.profile ? ` (${v.profile})` : ''} ${v.width ?? '?'}x${v.height ?? '?'} ${v.fps ?? '?'} fps ${v.bitDepth ?? '?'}-bit${v.hdr ? ` ${v.hdr}` : ''}`))
  m.audio.forEach((a, i) =>
    L.push(`  Audio ${i + 1}: ${a.codecLabel} ${a.channels ?? '?'} ch ${a.sampleRate ?? '?'} Hz${a.language ? ` [${a.language}]` : ''}`))
  m.subs.forEach((t, i) =>
    L.push(`  Subtitles ${i + 1}: ${t.codecLabel}${t.language ? ` [${t.language}]` : ''}`))
  L.push('')
  L.push('SCAN')
  L.push(`  Read ${fmtBytes(r.scan.bytesRead)} across ${r.scan.segments.length} segments in ${r.scan.msElapsed} ms (local MediaInfo WASM)`)
  L.push('')
  L.push('ESTIMATED COMPATIBILITY (support tables, current stable versions)')
  r.verdicts.forEach((v) => L.push(`  ${v.target.name}: ${VERDICT_WORD[v.verdict]} (${v.score}/100). ${v.headline}`))
  if (r.diagnosis.length > 0) {
    L.push('')
    L.push('DIAGNOSIS')
    r.diagnosis.forEach((d) =>
      L.push(`  [${d.severity.toUpperCase()}] ${d.component}: ${d.title}${d.fix ? ` | Fix: ${d.fix}` : ''} | Affects: ${d.affects.join(', ')}`))
  }
  L.push('')
  L.push('PRESCRIPTIONS')
  r.prescriptions.forEach((p) => {
    L.push(`  ${p.recommended ? '[recommended] ' : ''}${p.title}`)
    if (p.command) L.push(`    ${p.command}`)
    p.notes.forEach((n) => L.push(`    - ${n}`))
  })
  return L.join('\n')
}

export function downloadText(fileName: string, text: string, mime = 'text/plain') {
  const blob = new Blob([text], { type: `${mime};charset=utf-8` })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = fileName
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}
