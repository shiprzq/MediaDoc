import { useCallback, useEffect, useRef, useState } from 'react'
import { analyzeFile } from './lib/analyzer'
import { fmtBytes } from './lib/format'
import type { FileResult, ScanSegment } from './lib/types'
import AnalyzingView from './components/AnalyzingView'
import FaqSection from './components/FaqSection'
import Footer from './components/Footer'
import Hero from './components/Hero'
import MatrixExplorer from './components/MatrixExplorer'
import Navbar from './components/Navbar'
import ReportView from './components/ReportView'
import { SectionHeading } from './components/Section'

type Stage = 'idle' | 'analyzing' | 'report'

export default function App() {
  const [stage, setStage] = useState<Stage>('idle')
  const [results, setResults] = useState<FileResult[]>([])
  const [active, setActive] = useState(0)
  const [queue, setQueue] = useState<{ index: number; total: number; name: string; size: number }>({
    index: 0, total: 0, name: '', size: 0,
  })
  const [progress, setProgress] = useState<{ scanned: number; total: number; segments: ScanSegment[] }>({
    scanned: 0, total: 0, segments: [],
  })
  const [startedAt, setStartedAt] = useState(0)
  const stageRef = useRef<HTMLDivElement>(null)

  const scrollToStage = useCallback(() => {
    window.setTimeout(() => stageRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60)
  }, [])

  const startFiles = useCallback(
    async (files: File[]) => {
      setStage('analyzing')
      setResults([])
      setActive(0)
      scrollToStage()
      const acc: FileResult[] = []
      for (let i = 0; i < files.length; i++) {
        const file = files[i]
        setQueue({ index: i, total: files.length, name: file.name, size: file.size })
        setProgress({ scanned: 0, total: file.size, segments: [] })
        setStartedAt(performance.now())
        try {
          const report = await analyzeFile(file, (scanned, total, segments) =>
            setProgress({ scanned, total, segments: [...segments] }))
          acc.push({ ok: true, file, report })
        } catch (e) {
          acc.push({
            ok: false,
            name: file.name,
            size: file.size,
            error: e instanceof Error ? e.message : 'Analysis failed for an unknown reason.',
          })
        }
        setResults([...acc])
      }
      setStage('report')
      scrollToStage()
    },
    [scrollToStage],
  )

  const reset = useCallback(() => {
    setStage('idle')
    setResults([])
    setActive(0)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [])

  useEffect(() => {
    document.title = 'MediaDoc: Media Compatibility Doctor'
  }, [])

  return (
    <div className="min-h-screen">
      <Navbar />

      <main>
        <Hero onFiles={startFiles} busy={stage === 'analyzing'} />

        <div ref={stageRef} className="scroll-mt-20">
          {stage === 'analyzing' && (
            <div className="mx-auto max-w-6xl py-14">
              <AnalyzingView
                fileName={queue.name}
                fileSize={queue.size}
                scanned={progress.scanned}
                total={progress.total}
                segments={progress.segments}
                startedAt={startedAt}
                queueLabel={queue.total > 1 ? `file ${queue.index + 1} of ${queue.total}` : undefined}
              />
              {results.length > 0 && (
                <div className="mx-auto max-w-3xl px-4 sm:px-6">
                  <p className="mb-2 font-mono text-[11px] uppercase tracking-[0.18em] text-mute">Finished so far</p>
                  <ul className="panel divide-y divide-line">
                    {results.map((r, i) => (
                      <li key={i} className="flex items-center justify-between gap-4 px-4 py-2.5">
                        <span className="min-w-0 truncate font-mono text-xs text-ink">
                          {r.ok ? r.report.media.fileName : r.name}
                        </span>
                        <span className="shrink-0 font-mono text-[11px] text-mute">
                          {r.ok
                            ? `${r.report.playsCount}/${r.report.verdicts.length} play`
                            : `unreadable (${fmtBytes(r.size)})`}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {stage === 'report' && results.length > 0 && (
            <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
              <ReportView results={results} active={active} onSelect={setActive} onReset={reset} />
            </section>
          )}
        </div>

        <section className="border-t border-line bg-surface">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
            <SectionHeading
              eyebrow="Reference"
              title="The compatibility matrix"
              sub="The same support tables the estimates use, laid out in full. Hover any cell for conditions."
            />
            <MatrixExplorer />
          </div>
        </section>

        <section className="border-t border-line">
          <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
            <SectionHeading
              eyebrow="Background"
              title="Why files refuse to play"
              sub="The six most common failure modes, in plain terms."
            />
            <FaqSection />
          </div>
        </section>

        <section className="border-t-2 border-ink">
          <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-6 px-4 py-14 sm:px-6">
            <div>
              <h2 className="text-2xl font-bold tracking-tight text-ink">Got a file that will not behave?</h2>
              <p className="mt-1 max-w-md text-sm text-mute">
                The check runs locally and takes about as long as reading the file headers takes.
              </p>
            </div>
            <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="btn">
              Analyze a file
            </button>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
